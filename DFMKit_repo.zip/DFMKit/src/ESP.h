// ESP.h —— 透视绘制（骨骼 / 方框 / 血条，掩体红、露头绿）
#pragma once
#include "DFMCommon.h"

namespace dfm {

class ESP {
public:
    static ESP& Shared();
    void Draw();          // 由 tick 调用（游戏线程构帧）
    void SetEnabled(bool on) { m_on = on; }
    bool Enabled() const { return m_on; }
private:
    bool m_on = true;
};

} // namespace dfm
