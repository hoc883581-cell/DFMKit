// ESP.mm —— 透视绘制实现
#include "ESP.h"
#include "Aimbot.h"
#include "Overlay.h"
#include "UE4.h"
#include "Config.h"
#include "Runtime.h"
#include <cmath>
#include <cstdio>

namespace dfm {

ESP& ESP::Shared() { static ESP e; return e; }

static inline bool Valid(const FVector2D& p) {
    if (p.X == 0.f && p.Y == 0.f) return false;
    if (p.X != p.X || p.Y != p.Y) return false;
    float w = ov::ScreenW(), h = ov::ScreenH();
    return p.X > -w * 0.5f && p.X < w * 1.5f && p.Y > -h * 0.5f && p.Y < h * 1.5f;
}

// 颜色规则（严格按需求）：
//   任一部位可见 → 绿
//   三档模式下，仅躯干可见 → 黄绿
//   全部被遮挡（在掩体后）→ 红
static void ColorOf(const AimTarget& t, float c[3]) {
    if (t.anyVisible()) {
        if (rt::g.threeTone && !t.headVisible && !t.neckVisible && t.bodyVisible) {
            c[0] = 0.70f; c[1] = 1.00f; c[2] = 0.24f;
        } else {
            c[0] = 0.00f; c[1] = 1.00f; c[2] = 0.40f;
        }
    } else {
        c[0] = 1.00f; c[1] = 0.13f; c[2] = 0.27f;
    }
}

void ESP::Draw() {
    if (!m_on || !rt::g.espEnabled) return;
    const auto& list = Aimbot::Shared().Targets();
    if (list.empty()) return;

    void* curTarget = Aimbot::Shared().CurrentTarget();
    ov::Begin();
    int drawn = 0;

    for (const auto& t : list) {
        if (t.isTeammate) continue;
        if (!Valid(t.headScr)) continue;
        if (t.worldDist > rt::g.espMaxDist) continue;
        if (drawn++ > 40) break;

        float c[3];
        ColorOf(t, c);
        const float a = 0.92f;
        const float th = rt::g.lineThick;

        auto L = [&](const FVector2D& p, const FVector2D& q, float w = 0.f) {
            if (!Valid(p) || !Valid(q)) return;
            ov::AddLine(p.X, p.Y, q.X, q.Y, w > 0.f ? w : th, c[0], c[1], c[2], a);
        };

        // ---------- 骨骼线 ----------
        if (rt::g.bone) {
            L(t.headScr, t.neckScr, th * 1.1f);
            L(t.neckScr, t.chestScr);
            L(t.chestScr, t.pelvisScr);
            // 腿：盆骨 → 大腿 → 小腿 → 脚
            L(t.pelvisScr, t.lThigh);
            L(t.lThigh, t.lCalf);
            L(t.lCalf, t.lFoot);
            L(t.pelvisScr, t.rThigh);
            L(t.rThigh, t.rCalf);
            L(t.rCalf, t.rFoot);
            // 头：一个小十字，方便看清露头
            float hr = 5.f;
            ov::AddLine(t.headScr.X - hr, t.headScr.Y, t.headScr.X + hr, t.headScr.Y, th, c[0], c[1], c[2], a);
            ov::AddLine(t.headScr.X, t.headScr.Y - hr, t.headScr.X, t.headScr.Y + hr, th, c[0], c[1], c[2], a);
        }

        // ---------- 方框 ----------
        FVector2D pts[6] = { t.headScr, t.neckScr, t.chestScr, t.pelvisScr, t.lFoot, t.rFoot };
        float minX = 1e9f, minY = 1e9f, maxX = -1e9f, maxY = -1e9f;
        int used = 0;
        for (auto& p : pts) {
            if (!Valid(p)) continue;
            minX = fminf(minX, p.X); maxX = fmaxf(maxX, p.X);
            minY = fminf(minY, p.Y); maxY = fmaxf(maxY, p.Y);
            ++used;
        }
        if (used >= 2) {
            float padX = 10.f, padTop = 16.f, padBot = 14.f;
            minX -= padX; maxX += padX;
            minY -= padTop; maxY += padBot;
            float bw = maxX - minX, bh = maxY - minY;
            if (bw > 6.f && bh > 12.f && bw < ov::ScreenW() && bh < ov::ScreenH()) {
                if (rt::g.box) {
                    ov::AddRect(minX, minY, bw, bh, c[0], c[1], c[2], a * 0.9f, false);
                    // 四角加粗，视觉更清晰
                    float k = 0.22f;
                    ov::AddLine(minX, minY, minX + bw * k, minY, 2.4f, c[0], c[1], c[2], a);
                    ov::AddLine(minX, minY, minX, minY + bh * k, 2.4f, c[0], c[1], c[2], a);
                    ov::AddLine(maxX, minY, maxX - bw * k, minY, 2.4f, c[0], c[1], c[2], a);
                    ov::AddLine(maxX, minY, maxX, minY + bh * k, 2.4f, c[0], c[1], c[2], a);
                }
                // ---------- 血条 ----------
                if (rt::g.hpBar && t.hpFrac < 1.01f) {
                    float hw = bw, hh = 3.0f, hy = minY - 6.f;
                    ov::AddRect(minX, hy, hw, hh, 0.f, 0.f, 0.f, 0.55f, true);
                    float f = t.hpFrac;
                    float rr = f > 0.5f ? 0.2f : 1.f;
                    float gg = f > 0.5f ? 1.f : 0.35f;
                    ov::AddRect(minX, hy, hw * f, hh, rr, gg, 0.15f, 0.95f, true);
                }
                // ---------- 距离 ----------
                if (rt::g.drawDistText) {
                    char buf[24];
                    snprintf(buf, sizeof(buf), "%dm", (int)(t.worldDist + 0.5f));
                    ov::AddText(minX + 2.f, maxY + 3.f, 9.f, c[0], c[1], c[2], 0.85f, buf);
                }
            }
        }

        // ---------- 当前自瞄目标高亮 ----------
        if (t.pawn == curTarget && Valid(t.headScr)) {
            float r = 13.f;
            ov::AddRect(t.headScr.X - r, t.headScr.Y - r, r * 2, r * 2, 1.f, 0.95f, 0.2f, 0.9f, false);
        }
    }

    // ---------- 自瞄 FOV 参考圈（调试用，可用配置关闭） ----------
#ifdef DRAW_FOV_CIRCLE
    if (rt::g.fovDeg > 0.5f) {
        float pxPerDeg = ov::ScreenH() / 58.f;
        float R = rt::g.fovDeg * pxPerDeg;
        float cx = ov::ScreenW() * 0.5f, cy = ov::ScreenH() * 0.5f;
        const int seg = 40;
        for (int i = 0; i < seg; ++i) {
            float a0 = (float)i / seg * 6.2831853f;
            float a1 = (float)(i + 1) / seg * 6.2831853f;
            ov::AddLine(cx + cosf(a0) * R, cy + sinf(a0) * R,
                        cx + cosf(a1) * R, cy + sinf(a1) * R,
                        1.0f, 1.f, 1.f, 1.f, 0.25f);
        }
    }
#endif

    ov::Commit();
}

} // namespace dfm
