// main.mm —— 入口 / 主循环 / 生命周期
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#include "Aimbot.h"
#include "ESP.h"
#include "Overlay.h"
#include "Stealth.h"
#include "UE4.h"
#include "Config.h"
#include "Runtime.h"

using namespace dfm;

static CADisplayLink* g_link = nil;
static CFTimeInterval g_last = 0;
static volatile bool  g_paused = false;
static uint32_t       g_frameNo = 0;
static bool           g_resolved = false;

@interface DFMLinkTarget : NSObject
- (void)onTick:(CADisplayLink*)link;
@end

@implementation DFMLinkTarget
- (void)onTick:(CADisplayLink*)link {
    if (g_paused) { g_last = 0; return; }

    CFTimeInterval now = CACurrentMediaTime();
    float dt = (g_last > 0.0) ? (float)(now - g_last) : (1.f / 120.f);
    g_last = now;
    if (dt > 0.10f) dt = 0.10f;          // 掉帧/切后台回来不要瞬移
    if (dt <= 0.f) return;

    // 屏幕尺寸/旋转（每 60 帧同步一次）
    if ((g_frameNo++ % 60) == 0) {
        CGRect b = [UIScreen mainScreen].bounds;
        CGFloat sc = [UIScreen mainScreen].scale;
        ov::SetScreen((float)(b.size.width * sc), (float)(b.size.height * sc), (float)sc);
    }

    if (!g_resolved) {
        g_resolved = ue4::Resolve();
        if (!g_resolved) return;
    }

    Aimbot::Shared().Tick(dt);
    ESP::Shared().Draw();
}
@end

static DFMLinkTarget* g_target = nil;

static void StartLoop() {
    if (g_link) return;
    g_target = [DFMLinkTarget new];
    g_link = [CADisplayLink displayLinkWithTarget:g_target selector:@selector(onTick:)];
    if (!g_link) return;
    // 120Hz 设备优先跑满，普通设备自动 60
    if ([g_link respondsToSelector:@selector(setPreferredFramesPerSecond:)]) {
        NSInteger maxFps = 60;
        if (@available(iOS 15.0, *)) {
            maxFps = (NSInteger)[UIScreen mainScreen].maximumFramesPerSecond;
        }
        g_link.preferredFramesPerSecond = maxFps;
    }
    [g_link addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];
    DFM_LOG("loop started");
}

static void StopLoop() {
    if (!g_link) return;
    [g_link invalidate];
    g_link = nil;
}

__attribute__((constructor))
static void DFMKitInit(void) {
    @autoreleasepool {
        // 1) 隐蔽层必须先上（任何后续符号解析都可能被 ACE 观察）
        Stealth::Install();

        // 2) 等游戏引擎初始化完成再挂渲染与逻辑
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.5 * NSEC_PER_SEC)),
                       dispatch_get_main_queue(), ^{
            CGRect b = [UIScreen mainScreen].bounds;
            CGFloat sc = [UIScreen mainScreen].scale;
            ov::SetScreen((float)(b.size.width * sc), (float)(b.size.height * sc), (float)sc);
            ov::Install();
            rt::Load();                          // 读 Frameworks/DFMConfig.plist
            Aimbot::Shared().ApplyRuntime();
            StartLoop();
        });

        // 3) 前后台
        NSNotificationCenter* nc = [NSNotificationCenter defaultCenter];
        [nc addObserverForName:UIApplicationDidEnterBackgroundNotification
                        object:nil queue:[NSOperationQueue mainQueue]
                    usingBlock:^(NSNotification* n) {
                        g_paused = true;
                        Stealth::OnEnterBackground();
                    }];
        [nc addObserverForName:UIApplicationWillEnterForegroundNotification
                        object:nil queue:[NSOperationQueue mainQueue]
                    usingBlock:^(NSNotification* n) {
                        g_paused = false;
                        g_last = 0;
                        Aimbot::Shared().InvalidateScan();
                        Stealth::OnEnterForeground();
                    }];
        // 4) 内存警告时降载（关掉透视，保自瞄）
        [nc addObserverForName:UIApplicationDidReceiveMemoryWarningNotification
                        object:nil queue:[NSOperationQueue mainQueue]
                    usingBlock:^(NSNotification* n) {
                        ESP::Shared().SetEnabled(false);
                    }];
    }
}
