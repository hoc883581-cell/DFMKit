// UE4.cpp —— 反射解析 / 对象遍历 / 反射调用 / 投影与可见性
#include "UE4.h"
#include <dlfcn.h>
#include <mach/mach.h>
#include <mach-o/dyld.h>
#include <mach-o/loader.h>
#include <mach/vm_region.h>
#include <mach/mach_vm.h>
#include <pthread.h>
#include <cstdio>
#include <cstdlib>
#include <mach-o/dyld.h>
#include <unordered_map>
#include <mutex>

namespace dfm {

// ---------------- 安全内存检查（带区域缓存，避免每帧 vm_region 风暴） ----------------
namespace {
struct RegCache { thread_local vm_address_t lo, hi; };
thread_local vm_address_t t_lo = 0, t_hi = 0;
}

bool IsReadable(const void* p, size_t n) {
    if (!p) return false;
    vm_address_t a = (vm_address_t)p;
    if (a >= t_lo && a + n <= t_hi) return true;
    vm_address_t addr = a;
    vm_size_t size = 0;
    vm_region_basic_info_data_64_t info;
    mach_msg_type_number_t cnt = VM_REGION_BASIC_INFO_COUNT_64;
    mach_port_t obj = MACH_PORT_NULL;
    kern_return_t kr = vm_region_64(mach_task_self(), &addr, &size,
                                    VM_REGION_BASIC_INFO_64,
                                    (vm_region_info_t)&info, &cnt, &obj);
    if (obj != MACH_PORT_NULL) mach_port_deallocate(mach_task_self(), obj);
    if (kr != KERN_SUCCESS) return false;
    if (!(info.protection & VM_PROT_READ)) return false;
    if (a < addr || a + n > addr + size) return false;
    t_lo = addr; t_hi = addr + size;
    return true;
}

namespace cfg { Offsets g_off; }

namespace ue4 {

typedef void (*PE_t)(void*, void*, void*);

// ---------------- 全局 ----------------
static void**  g_gworld   = nullptr;   // &GWorld
static uptr    g_gobjects = 0;         // &GUObjectArray
static uptr    g_names    = 0;         // &GNames (FNamePool)
static u8**    g_blocks   = nullptr;   // FNamePool.Blocks
static u32     g_nameCurBlock = 0;
static u32     g_nameCurCursor = 0;
static u32     g_itemStride = 0x18;
static u8**    g_chunks   = nullptr;
static i32     g_maxElems = 0;
static i32     g_numElems = 0;
static PE_t    g_pe       = nullptr;
static bool    g_ready    = false;

template <class T> static T Min(T a, T b) { return a < b ? a : b; }
static void HookPEBody() {}

static u32 Rd32(const void* b, size_t o) { u32 v = 0; Rd<u32>(b, o, v); return v; }
static u16 Rd16(const void* b, size_t o) { u16 v = 0; Rd<u16>(b, o, v); return v; }

void* ImageBase(const char* imageName) {
    uint32_t n = _dyld_image_count();
    for (uint32_t i = 0; i < n; ++i) {
        const char* nm = _dyld_get_image_name(i);
        if (nm && strstr(nm, imageName)) return (void*)_dyld_get_image_header(i);
    }
    return nullptr;
}

// ---------------- FName ----------------
std::string NameOf(u32 idx) {
    if (!g_blocks) return "";
    u32 b = idx >> 16, o = idx & 0xFFFF;
    if (b > g_nameCurBlock + 1) return "";
    u8* blk = g_blocks[b];
    if (!blk) return "";
    if (b == g_nameCurBlock && o * 2 > g_nameCurCursor + 0x200) return "";
    u8* e = blk + (size_t)o * cfg::g_off.off_NameStride;
    if (!IsReadable(e, 4)) return "";
    u16 h = *(u16*)e;
    bool wide = (h & 1) != 0;

    auto tryLen = [&](int len) -> std::string {
        if (len <= 0 || len > 1024) return "";
        if (!IsReadable(e + 2, wide ? len * 2 : len)) return "";
        std::string s;
        s.reserve(len);
        for (int i = 0; i < len; ++i) {
            uint32_t c = wide ? ((u16*)(e + 2))[i] : (uint8_t)e[2 + i];
            if (c == 0) return "";
            if (c < 0x20 || c > 0x7E) return "";
            s.push_back((char)c);
        }
        return s;
    };
    // UE4.27: bIsWide:1 | Len:15  ；UE5: hash:5 | Len:10 | Wide:1
    std::string s = tryLen(h >> 1);
    if (s.empty()) s = tryLen(h >> 6);
    return s;
}

std::string NameOfObject(void* obj) {
    if (!obj) return "";
    FName n;
    if (!Rd<FName>(obj, cfg::g_off.off_NamePrivate, n)) return "";
    return NameOf(n.Index);
}

void* ClassOf(void* obj) { return Ptr(obj, cfg::g_off.off_ClassPrivate); }

std::string ClassNameOf(void* obj) {
    void* c = ClassOf(obj);
    return c ? NameOfObject(c) : "";
}

bool IsA(void* obj, const char* cls) {
    if (!obj) return false;
    void* c = ClassOf(obj);
    for (int depth = 0; c && depth < 32; ++depth) {
        if (NameOfObject(c) == cls) return true;
        void* sup = Ptr(c, cfg::g_off.off_SuperStruct);
        if (sup == c) break;
        c = sup;
    }
    return false;
}

// ---------------- 对象表 ----------------
i32 NumElementsRaw() { return g_numElems; }

u32 NumObjects() { return (u32)g_numElems; }

void* ObjectAt(u32 idx) {
    if ((i32)idx >= g_numElems || !g_chunks) return nullptr;
    u8* chunk = g_chunks[idx >> 16];
    if (!chunk) return nullptr;
    u8* item = chunk + (size_t)(idx & 0xFFFF) * g_itemStride;
    return *(void**)item;
}

static bool ValidateItemStride(u32 stride) {
    int hits = 0, tries = 0;
    for (u32 i = 0; i < (u32)Min(g_numElems, 4096) && tries < 256; ++i, ++tries) {
        u8* chunk = g_chunks[i >> 16];
        if (!chunk) continue;
        void* o = *(void**)(chunk + (size_t)(i & 0xFFFF) * stride);
        if (!o || !IsReadable(o, 0x40)) continue;
        void* c = Ptr(o, cfg::g_off.off_ClassPrivate);
        if (!c || !IsReadable(c, 0x40)) continue;
        void* mc = Ptr(c, cfg::g_off.off_ClassPrivate);   // UClass 的类应是自己
        if (mc == c) { if (++hits >= 3) return true; }
    }
    return false;
}


// ---------------- 解析 ----------------


// ---------------- Offsets.plist 覆盖（无 Foundation 依赖的极简解析） ----------------
static u32 PlistInt(const char* xml, const char* key, u32 dflt) {
    char pat[160];
    snprintf(pat, sizeof(pat), "<key>%s</key>", key);
    const char* p = strstr(xml, pat);
    if (!p) return dflt;
    p = strstr(p, "<integer>");
    if (!p) return dflt;
    p += 9;
    return (u32)strtoul(p, nullptr, 10);
}

bool ResolveFromPlist() {
    char exe[4096] = {0};
    uint32_t sz = sizeof(exe);
    if (_NSGetExecutablePath(exe, &sz) != 0) return false;
    char* slash = strrchr(exe, '/');
    if (!slash) return false;
    *slash = 0;
    char path[4200];
    snprintf(path, sizeof(path), "%s/Frameworks/Offsets.plist", exe);
    FILE* f = fopen(path, "rb");
    if (!f) {
        snprintf(path, sizeof(path), "%s/Offsets.plist", exe);
        f = fopen(path, "rb");
        if (!f) return false;
    }
    static char buf[16384];
    size_t n = fread(buf, 1, sizeof(buf) - 1, f);
    fclose(f);
    if (n < 16) return false;
    buf[n] = 0;
    auto& o = cfg::g_off;
    o.idx_ProcessEvent = PlistInt(buf, "idx_ProcessEvent", o.idx_ProcessEvent);
    o.off_ClassPrivate = PlistInt(buf, "off_ClassPrivate", o.off_ClassPrivate);
    o.off_NamePrivate  = PlistInt(buf, "off_NamePrivate",  o.off_NamePrivate);
    o.off_OuterPrivate = PlistInt(buf, "off_OuterPrivate", o.off_OuterPrivate);
    o.off_SuperStruct  = PlistInt(buf, "off_SuperStruct",  o.off_SuperStruct);
    o.off_Children     = PlistInt(buf, "off_Children",     o.off_Children);
    o.off_ChildProps   = PlistInt(buf, "off_ChildProps",   o.off_ChildProps);
    o.off_PropertiesSize = PlistInt(buf, "off_PropertiesSize", o.off_PropertiesSize);
    o.off_PropertyLink = PlistInt(buf, "off_PropertyLink", o.off_PropertyLink);
    o.off_PropNext     = PlistInt(buf, "off_PropNext",     o.off_PropNext);
    o.off_PropName     = PlistInt(buf, "off_PropName",     o.off_PropName);
    o.off_PropArrayDim = PlistInt(buf, "off_PropArrayDim", o.off_PropArrayDim);
    o.off_PropElemSize = PlistInt(buf, "off_PropElemSize", o.off_PropElemSize);
    o.off_PropOffset   = PlistInt(buf, "off_PropOffset",   o.off_PropOffset);
    o.off_FuncFlags    = PlistInt(buf, "off_FuncFlags",    o.off_FuncFlags);
    o.off_ParmsSize    = PlistInt(buf, "off_ParmsSize",    o.off_ParmsSize);
    o.off_ReturnOffset = PlistInt(buf, "off_ReturnOffset", o.off_ReturnOffset);
    o.off_ObjObjects   = PlistInt(buf, "off_ObjObjects",   o.off_ObjObjects);
    o.off_MaxElements  = PlistInt(buf, "off_MaxElements",  o.off_MaxElements);
    o.off_NumElements  = PlistInt(buf, "off_NumElements",  o.off_NumElements);
    o.off_NamesBlocks  = PlistInt(buf, "off_NamesBlocks",  o.off_NamesBlocks);
    o.off_NameStride   = PlistInt(buf, "off_NameStride",   o.off_NameStride);
    o.off_RootComponent    = PlistInt(buf, "off_RootComponent",    o.off_RootComponent);
    o.off_RelativeLocation = PlistInt(buf, "off_RelativeLocation", o.off_RelativeLocation);
    o.off_AcknowledgedPawn = PlistInt(buf, "off_AcknowledgedPawn", o.off_AcknowledgedPawn);
    o.off_ControlRotation  = PlistInt(buf, "off_ControlRotation",  o.off_ControlRotation);
    o.off_Mesh             = PlistInt(buf, "off_Mesh",             o.off_Mesh);
    static u32 stride = PlistInt(buf, "itemStride", 0x18);
    g_itemStride = stride ? stride : 0x18;
    DFM_LOG("plist loaded: %s", path);
    return true;
}

bool Resolve() {
    if (g_ready) return true;
    static bool plistLoaded = false;
    if (!plistLoaded) { plistLoaded = true; ResolveFromPlist(); }

    // 1) 符号直取（UE4 的 ENGINE_API 全局变量在 iOS 上默认可见）
    g_gworld   = (void**)dlsym(RTLD_DEFAULT, "GWorld");
    g_gobjects = (uptr)dlsym(RTLD_DEFAULT, "GUObjectArray");
    g_names    = (uptr)dlsym(RTLD_DEFAULT, "GNames");
    if (!g_gobjects) g_gobjects = (uptr)dlsym(RTLD_DEFAULT, "_GUObjectArray");
    if (!g_names)    g_names    = (uptr)dlsym(RTLD_DEFAULT, "FNamePool");
    if (!g_gworld)   g_gworld   = (void**)dlsym(RTLD_DEFAULT, "_GWorld");

    // 2) GUObjectArray 内部
    if (g_gobjects) {
        uptr base = g_gobjects + cfg::g_off.off_ObjObjects;
        g_chunks   = *(u8***)base;
        g_maxElems = (i32)Rd32((void*)base, cfg::g_off.off_MaxElements);
        g_numElems = (i32)Rd32((void*)base, cfg::g_off.off_NumElements);
        if (g_numElems <= 0 || g_numElems > 40'000'000) g_numElems = g_maxElems;
        // 自检 item stride（0x18 / 0x10 两种布局）
        if (!ValidateItemStride(g_itemStride)) {
            if (ValidateItemStride(0x18)) g_itemStride = 0x18;
            else if (ValidateItemStride(0x10)) g_itemStride = 0x10;
            else if (ValidateItemStride(0x30)) g_itemStride = 0x30;
        }
    }

    // 3) FNamePool
    if (g_names) {
        g_blocks = *(u8***)(g_names + cfg::g_off.off_NamesBlocks);
        g_nameCurBlock  = Rd32((void*)g_names, 0x08);
        g_nameCurCursor = Rd32((void*)g_names, 0x0C);
        if (g_nameCurBlock > 8191) g_nameCurBlock = 8191;
    }

    g_ready = (g_gworld && g_gobjects && g_names);
    DFM_LOG("resolve world=%p objs=%p names=%p num=%d stride=%u ready=%d",
            g_gworld, (void*)g_gobjects, (void*)g_names, g_numElems, g_itemStride, (int)g_ready);
    if (g_ready) HookPEBody();
    return g_ready;
}

void* World() { return (g_gworld && IsReadable(g_gworld, 8)) ? *g_gworld : nullptr; }

// ---------------- ProcessEvent ----------------
void* PE() { return (void*)g_pe; }

PE_t PE_t_Resolve(void* obj) {
    if (!obj) return nullptr;
    void** vt = *(void***)obj;
    if (!vt) return nullptr;
    return (PE_t)vt[cfg::g_off.idx_ProcessEvent];
}

static void InstallPE(PE_t fn) { g_pe = fn; }

void ProcessEvent(void* obj, void* fn, void* parms) {
    if (!obj || !fn) return;
    if (!g_pe) InstallPE(PE_t_Resolve(obj));
    if (!g_pe) return;
    g_pe(obj, fn, parms);
}

// ---------------- 属性链 ----------------
static void* FindPropInChain(void* ustruct, const char* name) {
    if (!ustruct) return nullptr;
    // 4.25+ 属性在 ChildProperties（FField 链）
    void* f = Ptr(ustruct, cfg::g_off.off_ChildProps);
    for (int i = 0; f && i < 512; ++i) {
        FName fn;
        if (!Rd<FName>(f, cfg::g_off.off_PropName, fn)) break;
        if (NameOf(fn.Index) == name) return f;
        void* nx = Ptr(f, cfg::g_off.off_PropNext);
        if (nx == f) break;
        f = nx;
    }
    return nullptr;
}

u32 PropOffset(void* obj, const char* propName) {
    if (!obj) return 0;
    void* cls = ClassOf(obj);
    for (int depth = 0; cls && depth < 32; ++depth) {
        void* p = FindPropInChain(cls, propName);
        if (p) return Rd32(p, cfg::g_off.off_PropOffset);
        void* sup = Ptr(cls, cfg::g_off.off_SuperStruct);
        if (sup == cls) break;
        cls = sup;
    }
    return 0;
}

bool GetBool(void* obj, const char* propName, bool dflt) {
    u32 off = PropOffset(obj, propName);
    if (!off) return dflt;
    uint8_t v = 0;
    return Rd<uint8_t>(obj, off, v) ? (v != 0) : dflt;
}

bool GetFloatProp(void* obj, const char* propName, float& out) {
    u32 off = PropOffset(obj, propName);
    return off && Rd<float>(obj, off, out);
}

bool GetIntProp(void* obj, const char* propName, i32& out) {
    u32 off = PropOffset(obj, propName);
    return off && Rd<i32>(obj, off, out);
}

void* GetObjProp(void* obj, const char* propName) {
    u32 off = PropOffset(obj, propName);
    return off ? Ptr(obj, off) : nullptr;
}

bool SetRotatorProp(void* obj, const char* propName, FRotator v) {
    u32 off = PropOffset(obj, propName);
    if (!off) return false;
    Wr<FRotator>(obj, off, v);
    return true;
}

// ---------------- UFunction ----------------
static std::unordered_map<std::string, void*> g_fnCache;
static std::mutex g_fnMtx;

void* FindFunction(void* cls, const char* fnName) {
    if (!cls || !fnName) return nullptr;
    std::string key = std::string(fnName) + "@" + std::to_string((uptr)cls);
    {
        std::lock_guard<std::mutex> lk(g_fnMtx);
        auto it = g_fnCache.find(key);
        if (it != g_fnCache.end()) return it->second;
    }
    void* f = Ptr(cls, cfg::g_off.off_Children);
    void* found = nullptr;
    for (int i = 0; f && i < 8192; ++i) {
        FName fn;
        if (!Rd<FName>(f, cfg::g_off.off_NamePrivate, fn)) break;
        if (NameOf(fn.Index) == fnName) { found = f; break; }
        void* nx = Ptr(f, 0x28);
        if (nx == f) break;
        f = nx;
    }
    {
        std::lock_guard<std::mutex> lk(g_fnMtx);
        g_fnCache[key] = found;
    }
    return found;
}

void* FindClass(const char* cls) {
    static std::unordered_map<std::string, void*> cache;
    auto it = cache.find(cls);
    if (it != cache.end()) return it->second;
    void* found = nullptr;
    u32 n = NumObjects();
    for (u32 i = 0; i < n; ++i) {
        void* o = ObjectAt(i);
        if (!o) continue;
        if (NameOfObject(o) != cls) continue;
        void* c = ClassOf(o);
        if (c && NameOfObject(c) == "Class") { found = o; break; }
    }
    cache[cls] = found;
    return found;
}

std::vector<void*> AllObjectsOfClass(const char* cls) {
    std::vector<void*> out;
    u32 n = NumObjects();
    out.reserve(256);
    for (u32 i = 0; i < n; ++i) {
        void* o = ObjectAt(i);
        if (!o) continue;
        void* c = ClassOf(o);
        if (!c) continue;
        if (NameOfObject(c) != cls) continue;
        out.push_back(o);
    }
    return out;
}

// ---------------- 参数块 ----------------
Params::Params(void* fnObj) {
    fn = fnObj;
    u16 ps = Rd16(fnObj, cfg::g_off.off_ParmsSize);
    retOff = Rd16(fnObj, cfg::g_off.off_ReturnOffset);
    size_t n = (ps > 8 && ps < 0x2000) ? ps : 0x100;
    buf.assign(n + 0x80, 0);
}

void Params::Set(const char* name, const void* data, size_t n) {
    void* p = FindPropInChain(fn, name);
    if (!p) { DFM_LOG("param not found: %s", name); return; }
    u32 off = Rd32(p, cfg::g_off.off_PropOffset);
    if (off + n > buf.size()) return;
    memcpy(buf.data() + off, data, n);
}

void Params::SetFVector(const char* n, FVector v)   { Set(n, &v, sizeof(v)); }
void Params::SetRotator(const char* n, FRotator v)  { Set(n, &v, sizeof(v)); }
void Params::SetFVector2D(const char* n, FVector2D v){ Set(n, &v, sizeof(v)); }
void Params::SetBool(const char* n, bool v)         { uint8_t b = v; Set(n, &b, 1); }
void Params::SetFloat(const char* n, float v)       { Set(n, &v, 4); }
void Params::SetInt(const char* n, i32 v)           { Set(n, &v, 4); }
void Params::SetObject(const char* n, void* v)      { Set(n, &v, 8); }

static i32 FindNameIndex(const char* s);

void Params::SetFName(const char* n, const char* value) {
    FName fnv{ FindNameIndex(value), 0 };
    Set(n, &fnv, sizeof(fnv));
}

FVector Params::GetFVector(const char* n) {
    void* p = FindPropInChain(fn, n);
    FVector v{};
    if (!p) return v;
    u32 off = Rd32(p, cfg::g_off.off_PropOffset);
    if (off + sizeof(v) <= buf.size()) memcpy(&v, buf.data() + off, sizeof(v));
    return v;
}
FVector2D Params::GetFVector2D(const char* n) {
    void* p = FindPropInChain(fn, n);
    FVector2D v{};
    if (!p) return v;
    u32 off = Rd32(p, cfg::g_off.off_PropOffset);
    if (off + sizeof(v) <= buf.size()) memcpy(&v, buf.data() + off, sizeof(v));
    return v;
}
bool Params::GetBool(const char* n) {
    void* p = FindPropInChain(fn, n);
    if (!p) return false;
    u32 off = Rd32(p, cfg::g_off.off_PropOffset);
    return (off < buf.size()) ? (buf[off] != 0) : false;
}

// ---------------- FName 反查（一次性，带缓存） ----------------
static std::unordered_map<std::string, i32> g_nameRev;

static i32 FindNameIndex(const char* s) {
    if (!s || !g_blocks) return 0;
    auto it = g_nameRev.find(s);
    if (it != g_nameRev.end()) return it->second;
    size_t L = strlen(s);
    i32 found = 0;
    for (u32 b = 0; b <= g_nameCurBlock && b < 8192 && !found; ++b) {
        u8* blk = g_blocks[b];
        if (!blk) continue;
        u32 limit = (b == g_nameCurBlock) ? (g_nameCurCursor / 2 + 1) : 65536;
        for (u32 o = 0; o < limit; o += 1) {
            u8* e = blk + (size_t)o * 2;
            u16 h = *(u16*)e;
            int len = h >> 1;
            if ((h & 1) || len <= 0 || len > 256) continue;
            if ((size_t)len != L) continue;
            if (!IsReadable(e + 2, L)) continue;
            if (memcmp(e + 2, s, L) == 0) { found = (i32)((b << 16) | o); break; }
        }
    }
    g_nameRev[s] = found;
    return found;
}

// ---------------- 常用对象 ----------------
void* GameState() {
    void* w = World();
    return w ? GetObjProp(w, "GameState") : nullptr;
}

void* LocalPC() {
    // 首选 UGameplayStatics::GetPlayerController(WorldContext, 0)
    static void* fn = nullptr;
    static void* cls = nullptr;
    if (!cls) cls = FindClass("GameplayStatics");
    if (cls && !fn) fn = FindFunction(cls, "GetPlayerController");
    void* w = World();
    if (fn && w) {
        Params p(fn);
        p.SetObject("WorldContextObject", w);
        p.SetInt("PlayerIndex", 0);
        ProcessEvent(cls, fn, p.buf.data());
        void* pc = nullptr;
        void* prop = FindPropInChain(fn, "ReturnValue");
        if (prop) {
            u32 off = Rd32(prop, cfg::g_off.off_PropOffset);
            if (off + 8 <= p.buf.size()) memcpy(&pc, p.buf.data() + off, 8);
        }
        if (pc) return pc;
    }
    // 兜底：找 AcknowledgedPawn 非空的 PlayerController
    auto all = AllObjectsOfClass("PlayerController");
    for (void* pc : all) {
        if (GetObjProp(pc, "AcknowledgedPawn")) return pc;
    }
    return all.empty() ? nullptr : all[0];
}

void* LocalPawn() {
    void* pc = LocalPC();
    if (!pc) return nullptr;
    void* pawn = GetObjProp(pc, "AcknowledgedPawn");
    if (pawn) return pawn;
    void* cam = GetObjProp(pc, "PlayerCameraManager");
    return cam ? GetObjProp(cam, "PCOwner") : nullptr;
}

FVector ActorLocation(void* actor) {
    FVector v{};
    if (!actor) return v;
    void* root = GetObjProp(actor, "RootComponent");
    if (!root) return v;
    u32 off = PropOffset(root, "RelativeLocation");
    if (!off) off = cfg::g_off.off_RelativeLocation;
    Rd<FVector>(root, off, v);
    return v;
}

FVector Velocity(void* actor) {
    FVector v{};
    if (!actor) return v;
    void* root = GetObjProp(actor, "RootComponent");
    if (!root) return v;
    u32 off = PropOffset(root, "ComponentVelocity");
    if (off) Rd<FVector>(root, off, v);
    return v;
}

FVector SocketLocation(void* comp, const char* bone) {
    static void* fn = nullptr;
    static void* cls = nullptr;
    if (!cls) cls = FindClass("SceneComponent");
    if (cls && !fn) fn = FindFunction(cls, "GetSocketLocation");
    FVector out{};
    if (!comp || !fn) return out;
    Params p(fn);
    p.SetFName("InSocketName", bone);
    ProcessEvent(comp, fn, p.buf.data());
    void* prop = FindPropInChain(fn, "ReturnValue");
    if (prop) {
        u32 off = Rd32(prop, cfg::g_off.off_PropOffset);
        if (off + 12 <= p.buf.size()) memcpy(&out, p.buf.data() + off, 12);
    }
    return out;
}

bool WorldToScreen(void* pc, const FVector& world, FVector2D& out) {
    static void* fn = nullptr;
    static void* cls = nullptr;
    if (!cls) cls = FindClass("PlayerController");
    if (cls && !fn) fn = FindFunction(cls, "ProjectWorldLocationToScreen");
    if (!pc || !fn) return false;
    Params p(fn);
    p.SetFVector("WorldLocation", world);
    p.SetBool("bPlayerViewportRelative", false);
    ProcessEvent(pc, fn, p.buf.data());
    out = p.GetFVector2D("ScreenLocation");
    bool ok = p.GetBool("ReturnValue");
    return ok && out.X == out.X && out.Y == out.Y;   // NaN 过滤
}

bool VisibleFromCamera(void* pc, const FVector& target, void* ignoreActor, float* outDist) {
    // 用 KismetSystemLibrary::LineTraceSingle（BlueprintCallable，走真实物理遮挡）
    static void* fn = nullptr;
    static void* cls = nullptr;
    static void* cdo = nullptr;
    if (!cls) { cls = FindClass("KismetSystemLibrary"); }
    if (!cdo && cls) {
        auto objs = AllObjectsOfClass("KismetSystemLibrary");
        if (!objs.empty()) cdo = objs[0];
    }
    void* w = World();
    if (!fn && cls) fn = FindFunction(cls, "LineTraceSingle");
    void* pawn = LocalPawn();
    FVector start{};
    if (pawn) {
        void* cam = GetObjProp(LocalPC(), "PlayerCameraManager");
        if (cam) {
            u32 off = PropOffset(cam, "CameraCache");
            (void)off;
        }
        start = ActorLocation(pawn);
        start.Z += 60.f;   // 眼高近似（探针失败时的兜底起点）
    }
    if (!fn || !cdo || !w) return true;  // 反射不可用时不做遮挡过滤（宁绿不红）

    Params p(fn);
    p.SetObject("WorldContextObject", w);
    p.SetFVector("Start", start);
    p.SetFVector("End", target);
    p.SetInt("TraceChannel", 0);       // ECC_Visibility
    p.SetBool("bTraceComplex", false);
    // ActorsToIgnore 空数组：直接写 0 长度（buf 已清零）
    p.SetInt("DrawDebugType", 0);
    p.SetBool("bIgnoreSelf", true);
    ProcessEvent(cdo, fn, p.buf.data());

    void* hitProp = FindPropInChain(fn, "OutHit");
    bool hit = false;
    if (hitProp) {
        u32 off = Rd32(hitProp, cfg::g_off.off_PropOffset);
        // FHitResult 的第一个成员是 float Time（1.0 = 没打到东西）
        float t = 1.f;
        if (off + 4 <= p.buf.size()) memcpy(&t, p.buf.data() + off, 4);
        hit = (t < 0.999f);
        if (hit && outDist) *outDist = t;
    }
    bool visible = !hit;
    if (ignoreActor && !visible) return false;
    return visible;
}

u32 AllocPoolObjects(std::vector<void*>& out) {
    out.clear();
    u32 n = NumObjects();
    out.reserve(2048);
    for (u32 i = 0; i < n; ++i) {
        void* o = ObjectAt(i);
        if (o) out.push_back(o);
    }
    return (u32)out.size();
}

bool ReadW2SMatrix(void* pc, float mat[16], FVector& camLoc, FRotator& camRot) {
    void* cam = GetObjProp(pc, "PlayerCameraManager");
    if (!cam) return false;
    u32 offLoc = PropOffset(cam, "CameraCache");
    (void)offLoc;
    // 兜底路径：直接用 ControlRotation + 玩家位置构造 view，交给 Metal 层做投影
    void* pawn = LocalPawn();
    if (!pawn) return false;
    camLoc = ActorLocation(pawn);
    camLoc.Z += 62.f;
    u32 offRot = PropOffset(pc, "ControlRotation");
    if (offRot) Rd<FRotator>(pc, offRot, camRot);
    return true;
}

} // namespace ue4
} // namespace dfm
