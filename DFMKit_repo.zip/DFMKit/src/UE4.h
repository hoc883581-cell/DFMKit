// UE4.h —— 不依赖硬编码地址的 UE4 反射层
#pragma once
#include "DFMCommon.h"
#include "Config.h"

namespace dfm { namespace ue4 {

// ---------- 初始化 ----------
bool Resolve();                       // 解析 GWorld / GUObjectArray / GNames
bool ResolveFromPlist();              // 从 res/Offsets.plist 覆盖默认偏移
void* ImageBase(const char* imageName);

// ---------- 全局对象 ----------
void* World();
void* LocalPC();
void* LocalPawn();
void* GameState();

// ---------- 对象表 ----------
void* ClassOf(void* obj);
u32   NumObjects();
void* ObjectAt(u32 idx);
std::string NameOf(u32 nameIndex);
std::string NameOfObject(void* obj);
std::string ClassNameOf(void* obj);
bool  IsA(void* obj, const char* cls);
void* FindClass(const char* cls);
std::vector<void*> AllObjectsOfClass(const char* cls);

// ---------- 反射调用 ----------
void* PE()                      ;    // ProcessEvent 函数指针
void  ProcessEvent(void* obj, void* fn, void* parms);
void* FindFunction(void* cls, const char* fnName);

// 参数块构造器：按属性名写参数，不依赖参数顺序
struct Params {
    void* fn = nullptr;
    std::vector<uint8_t> buf;
    u32 retOff = 0;
    explicit Params(void* fnObj);
    void Set(const char* name, const void* data, size_t n);
    void SetFVector(const char* n, FVector v);
    void SetRotator(const char* n, FRotator v);
    void SetFVector2D(const char* n, FVector2D v);
    void SetBool(const char* n, bool v);
    void SetFloat(const char* n, float v);
    void SetInt(const char* n, i32 v);
    void SetObject(const char* n, void* v);
    void SetFName(const char* n, const char* value);   // 自动查 GNames
    FVector  GetFVector(const char* n);
    FVector2D GetFVector2D(const char* n);
    bool     GetBool(const char* n);
};

// ---------- 属性直读（偏移探测失败时自动回退到反射调用） ----------
u32   PropOffset(void* obj, const char* propName);
bool  GetBool(void* obj, const char* propName, bool dflt = false);
bool  GetFloatProp(void* obj, const char* propName, float& out);
bool  GetIntProp(void* obj, const char* propName, i32& out);
void* GetObjProp(void* obj, const char* propName);
std::string GetNameProp(void* obj, const char* propName);
bool  SetRotatorProp(void* obj, const char* propName, FRotator v);

// ---------- 位置 / 投影 ----------
FVector ActorLocation(void* actor);
FVector SocketLocation(void* meshComp, const char* bone);
FVector Velocity(void* actor);
bool  WorldToScreen(void* pc, const FVector& world, FVector2D& out);
bool  VisibleFromCamera(void* pc, const FVector& target, void* ignoreActor, float* outDist = nullptr);

// ---------- 工具 ----------
bool  ReadW2SMatrix(void* pc, float mat[16], FVector& camLoc, FRotator& camRot); // 兜底手算
u32   AllocPoolObjects(std::vector<void*>& out);  // 带类型标记的对象池快照

} // namespace ue4
} // namespace dfm
