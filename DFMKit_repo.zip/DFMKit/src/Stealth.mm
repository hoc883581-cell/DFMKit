// Stealth.mm —— 隐蔽层：image 隐藏 / 反调试 / 越狱痕迹 / dyld 符号重绑
#include "Stealth.h"
#include "Config.h"
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#include <mach-o/dyld.h>
#include <mach-o/nlist.h>
#include <mach-o/loader.h>
#include <mach-o/dyld_images.h>
#include <sys/sysctl.h>
#include <sys/ptrace.h>
#include <sys/stat.h>
#include <mach/mach_vm.h>
#include <mach/vm_region.h>
#include <unistd.h>
#include <dlfcn.h>
#include <errno.h>
#include <string.h>

// ============ 精简 fishhook：重绑 Mach-O 的 lazy/non-lazy 符号指针 ============
namespace {

struct Rebind { const char* name; void* repl; void** orig; };

int RebindSymbols(Rebind rb[], size_t n) {
    for (size_t i = 0; i < n; ++i) if (rb[i].orig) *rb[i].orig = nullptr;

    for (uint32_t idx = 0; idx < _dyld_image_count(); ++idx) {
        const struct mach_header_64* mh = (const struct mach_header_64*)_dyld_get_image_header(idx);
        if (!mh || mh->magic != MH_MAGIC_64) continue;
        intptr_t slide = _dyld_get_image_vmaddr_slide(idx);

        const struct symtab_command*  symtab  = nullptr;
        const struct dysymtab_command* dysym  = nullptr;
        const struct segment_command_64* linkedit = nullptr;

        uintptr_t cur = (uintptr_t)mh + sizeof(struct mach_header_64);
        for (uint32_t c = 0; c < mh->ncmds; ++c) {
            const struct load_command* lc = (const struct load_command*)cur;
            if (lc->cmd == LC_SYMTAB)  symtab = (const struct symtab_command*)lc;
            else if (lc->cmd == LC_DYSYMTAB) dysym = (const struct dysymtab_command*)lc;
            else if (lc->cmd == LC_SEGMENT_64) {
                const struct segment_command_64* sg = (const struct segment_command_64*)lc;
                if (strcmp(sg->segname, "__LINKEDIT") == 0) linkedit = sg;
            }
            cur += lc->cmdsize;
            if (lc->cmdsize == 0) break;
        }
        if (!symtab || !dysym || !linkedit) continue;

        uintptr_t base = (uintptr_t)linkedit->vmaddr - linkedit->fileoff + slide;
        const nlist_64*  syms  = (const nlist_64*)(base + symtab->symoff);
        const char*      strs  = (const char*)(base + symtab->stroff);
        const uint32_t*  indir = (const uint32_t*)(base + dysym->indirectsymoff);

        cur = (uintptr_t)mh + sizeof(struct mach_header_64);
        for (uint32_t c = 0; c < mh->ncmds; ++c) {
            const struct load_command* lc = (const struct load_command*)cur;
            if (lc->cmd == LC_SEGMENT_64) {
                const struct segment_command_64* sg = (const struct segment_command_64*)lc;
                const char* sn = sg->segname;
                bool dataSeg = (strncmp(sn, "__DATA", 6) == 0) || (strncmp(sn, "__AUTH", 6) == 0);
                if (dataSeg) {
                    const struct section_64* sec =
                        (const struct section_64*)((uintptr_t)sg + sizeof(*sg));
                    for (uint32_t s = 0; s < sg->nsects; ++s, ++sec) {
                        uint32_t type = sec->flags & SECTION_TYPE;
                        if (type != S_LAZY_SYMBOL_POINTERS && type != S_NON_LAZY_SYMBOL_POINTERS)
                            continue;
                        uint32_t count = (uint32_t)(sec->size / sizeof(void*));
                        void** ptrs = (void**)((uintptr_t)sec->addr + slide);
                        for (uint32_t p = 0; p < count; ++p) {
                            uint32_t si = indir[sec->reserved1 + p];
                            if (si == INDIRECT_SYMBOL_ABS || si == INDIRECT_SYMBOL_LOCAL) continue;
                            const char* name = strs + syms[si].n_un.n_strx;
                            if (!name || !name[0]) continue;
                            const char* noUnderscore = (name[0] == '_') ? name + 1 : name;
                            for (size_t r = 0; r < n; ++r) {
                                if (strcmp(name, rb[r].name) == 0 ||
                                    strcmp(noUnderscore, rb[r].name) == 0) {
                                    if (ptrs[p] == rb[r].repl) continue;
                                    if (rb[r].orig && *rb[r].orig == nullptr) *rb[r].orig = ptrs[p];
                                    ptrs[p] = rb[r].repl;
                                }
                            }
                        }
                    }
                }
            }
            cur += lc->cmdsize;
            if (lc->cmdsize == 0) break;
        }
    }
    return 0;
}

// ---- C 函数指针 ---- 
typedef uint32_t (*fn_dyld_image_count)(void);
typedef const char* (*fn_dyld_get_image_name)(uint32_t);
typedef const struct mach_header* (*fn_dyld_get_image_header)(uint32_t);
typedef int (*fn_dladdr)(const void*, Dl_info*);
typedef int (*fn_sysctl)(int*, u_int, void*, size_t*, void*, size_t);
typedef int (*fn_getppid)(void);
typedef long (*fn_ptrace)(int, pid_t, caddr_t, int);
typedef int (*fn_stat)(const char*, struct stat*);
typedef int (*fn_lstat)(const char*, struct stat*);
typedef int (*fn_access)(const char*, int);
typedef kern_return_t (*fn_vm_region_64)(vm_map_t, vm_address_t*, vm_size_t*, vm_region_flavor_t,
                                         vm_region_info_t, mach_msg_type_number_t*, mach_port_t*);
typedef kern_return_t (*fn_mach_vm_region_recurse)(vm_map_read_t, mach_vm_address_t*, mach_vm_size_t*,
                                                   natural_t*, vm_region_recurse_info_t, mach_msg_type_number_t*);
typedef kern_return_t (*fn_mach_vm_read_overwrite)(vm_map_read_t, mach_vm_address_t, mach_vm_size_t,
                                                   mach_vm_address_t, mach_vm_size_t*);
typedef kern_return_t (*fn_task_info)(task_name_t, task_flavor_t, task_info_t, mach_msg_type_number_t*);
typedef int (*fn_csops)(pid_t, uint32_t, void*, size_t);

fn_dyld_image_count        o_image_count  = nullptr;
fn_dyld_get_image_name     o_image_name   = nullptr;
fn_dyld_get_image_header   o_image_header = nullptr;
fn_dladdr                  o_dladdr       = nullptr;
fn_sysctl                  o_sysctl       = nullptr;
fn_getppid                 o_getppid      = nullptr;
fn_ptrace                  o_ptrace       = nullptr;
fn_stat                    o_stat         = nullptr;
fn_lstat                   o_lstat        = nullptr;
fn_access                  o_access       = nullptr;
fn_vm_region_64            o_vm_region64  = nullptr;
fn_mach_vm_region_recurse  o_vm_rec       = nullptr;
fn_mach_vm_read_overwrite  o_vm_read      = nullptr;
fn_task_info               o_task_info    = nullptr;
fn_csops                   o_csops        = nullptr;

uintptr_t g_selfLo = 0, g_selfHi = 0;

int g_selfIndex = -1;

} // namespace

namespace dfm {

int Stealth::SelfImageIndex() {
    if (g_selfIndex >= 0) return g_selfIndex;
    Dl_info info{};
    if (o_dladdr && o_dladdr((const void*)&Stealth::SelfImageIndex, &info) && info.dli_fname) {
        uint32_t n = o_image_count ? o_image_count() : _dyld_image_count();
        for (uint32_t i = 0; i < n; ++i) {
            const char* nm = o_image_name ? o_image_name(i) : _dyld_get_image_name(i);
            if (nm && strcmp(nm, info.dli_fname) == 0) { g_selfIndex = (int)i; break; }
        }
    }
    if (g_selfIndex < 0) {
        uint32_t n = _dyld_image_count();
        if (n > 0) g_selfIndex = (int)(n - 1);   // 最后加载的就是自己
    }
    return g_selfIndex;
}

// ---------- 隐藏自身 image ----------
static uint32_t DFM_image_count(void) {
    uint32_t n = o_image_count ? o_image_count() : _dyld_image_count();
    return (n > 1) ? (n - 1) : n;
}
static const char* DFM_image_name(uint32_t idx) {
    uint32_t n = o_image_count ? o_image_count() : _dyld_image_count();
    int self = Stealth::SelfImageIndex();
    if (self >= 0 && (int)idx >= self) {
        uint32_t real = idx + 1;
        if (real >= n) return "";
        return o_image_name ? o_image_name(real) : _dyld_get_image_name(real);
    }
    return o_image_name ? o_image_name(idx) : _dyld_get_image_name(idx);
}
static const struct mach_header* DFM_image_header(uint32_t idx) {
    uint32_t n = o_image_count ? o_image_count() : _dyld_image_count();
    int self = Stealth::SelfImageIndex();
    if (self >= 0 && (int)idx >= self) {
        uint32_t real = idx + 1;
        if (real >= n) return nullptr;
        return o_image_header ? o_image_header(real) : _dyld_get_image_header(real);
    }
    return o_image_header ? o_image_header(idx) : _dyld_get_image_header(idx);
}
static int DFM_dladdr(const void* addr, Dl_info* info) {
    int r = o_dladdr ? o_dladdr(addr, info) : 0;
    if (r && info && info->dli_fname) {
        const char* nm = info->dli_fname;
        if (strstr(nm, "DFMKit") || strstr(nm, "dfmkit")) {
            info->dli_fname = "/usr/lib/libAppSupport.dylib";
            info->dli_sname = "";
        }
    }
    return r;
}

// ---------- 自身 image 范围 ----------
static void ComputeSelfRange() {
    int idx = Stealth::SelfImageIndex();
    if (idx < 0) return;
    const struct mach_header_64* mh =
        (const struct mach_header_64*)_dyld_get_image_header((uint32_t)idx);
    if (!mh || mh->magic != MH_MAGIC_64) return;
    intptr_t slide = _dyld_get_image_vmaddr_slide((uint32_t)idx);
    uintptr_t cur = (uintptr_t)mh + sizeof(struct mach_header_64);
    uintptr_t lo = (uintptr_t)-1, hi = 0;
    for (uint32_t i = 0; i < mh->ncmds; ++i) {
        const struct load_command* lc = (const struct load_command*)cur;
        if (lc->cmd == LC_SEGMENT_64) {
            const struct segment_command_64* sg = (const struct segment_command_64*)lc;
            uintptr_t a = (uintptr_t)(sg->vmaddr + slide);
            uintptr_t b = a + sg->vmsize;
            if (a < lo) lo = a;
            if (b > hi) hi = b;
        }
        cur += lc->cmdsize;
        if (!lc->cmdsize) break;
    }
    g_selfLo = lo; g_selfHi = hi;
}

static inline bool InSelf(uintptr_t a, uintptr_t n = 1) {
    return g_selfLo && a >= g_selfLo && (a + n) <= g_selfHi;
}

// ---------- 内存扫描隐身：vm_region 系列跳过自身区域 ----------
static kern_return_t DFM_vm_region64(vm_map_t t, vm_address_t* addr, vm_size_t* size,
                                     vm_region_flavor_t fl, vm_region_info_t info,
                                     mach_msg_type_number_t* cnt, mach_port_t* obj) {
    if (!o_vm_region64) return KERN_FAILURE;
    kern_return_t r = o_vm_region64(t, addr, size, fl, info, cnt, obj);
    if (r == KERN_SUCCESS && addr && size && InSelf(*addr)) {
        if (obj && *obj != MACH_PORT_NULL) {
            mach_port_deallocate(mach_task_self(), *obj);
            *obj = MACH_PORT_NULL;
        }
        vm_address_t a2 = g_selfHi;
        vm_size_t s2 = 0;
        r = o_vm_region64(t, &a2, &s2, fl, info, cnt, obj);
        if (r == KERN_SUCCESS) { *addr = a2; *size = s2; }
        else { *addr = g_selfHi; *size = 0; }
    }
    return r;
}

static kern_return_t DFM_vm_recurse(vm_map_read_t t, mach_vm_address_t* addr, mach_vm_size_t* size,
                                    natural_t* depth, vm_region_recurse_info_t info,
                                    mach_msg_type_number_t* cnt) {
    if (!o_vm_rec) return KERN_FAILURE;
    kern_return_t r = o_vm_rec(t, addr, size, depth, info, cnt);
    if (r == KERN_SUCCESS && addr && size && InSelf((uintptr_t)*addr)) {
        mach_vm_address_t a2 = g_selfHi;
        mach_vm_size_t s2 = 0;
        natural_t d2 = 0;
        r = o_vm_rec(t, &a2, &s2, &d2, info, cnt);
        if (r == KERN_SUCCESS) { *addr = a2; *size = s2; *depth = d2; }
        else { *addr = g_selfHi; *size = 0; }
    }
    return r;
}

// 直接读内存（ACE 常用它校验 __TEXT 段指令）→ 命中自身就直接失败
static kern_return_t DFM_vm_read_overwrite(vm_map_read_t t, mach_vm_address_t src,
                                           mach_vm_size_t n, mach_vm_address_t dst,
                                           mach_vm_size_t* out) {
    if (InSelf((uintptr_t)src, (uintptr_t)n)) {
        if (out) *out = 0;
        return KERN_INVALID_ADDRESS;
    }
    if (!o_vm_read) return KERN_FAILURE;
    return o_vm_read(t, src, n, dst, out);
}

// ---------- 直接改写 dyld 的 image 列表（ACE 常绕过 dyld API 直读这张表） ----------
extern "C" const struct dyld_all_image_infos* _dyld_get_all_image_infos(void);

static void PatchDyldImageList() {
    const struct dyld_all_image_infos* cai = _dyld_get_all_image_infos();
    if (!cai) return;
    struct dyld_all_image_infos* ai = (struct dyld_all_image_infos*)cai;
    uint32_t cnt = ai->infoArrayCount;
    const struct dyld_image_info* arr = ai->infoArray;
    if (!arr || cnt == 0 || cnt > 8192) return;
    int idx = Stealth::SelfImageIndex();
    if (idx < 0) return;
    uintptr_t selfHdr = (uintptr_t)_dyld_get_image_header((uint32_t)idx);
    for (uint32_t i = 0; i < cnt; ++i) {
        if ((uintptr_t)arr[i].imageLoadAddress == selfHdr) {
            vm_address_t page = (vm_address_t)((uintptr_t)arr & ~(uintptr_t)0x3FFF);
            vm_size_t len = (vm_size_t)(((uintptr_t)(arr + cnt)) - page + 16);
            kern_return_t kr = vm_protect(mach_task_self(), page, len, false,
                                          VM_PROT_READ | VM_PROT_WRITE | VM_PROT_COPY);
            if (kr != KERN_SUCCESS) return;
            memmove((void*)&arr[i], (void*)&arr[i + 1],
                    (size_t)(cnt - i - 1) * sizeof(struct dyld_image_info));
            ai->infoArrayCount = cnt - 1;
            DFM_LOG("dyld image list patched: %u -> %u", cnt, cnt - 1);
            return;
        }
    }
}

// ---------- task_info：TASK_DYLD_INFO 里的地址也要指向被改过的表 ----------
static kern_return_t DFM_task_info(task_name_t t, task_flavor_t fl, task_info_t info,
                                   mach_msg_type_number_t* cnt) {
    if (!o_task_info) return KERN_FAILURE;
    kern_return_t r = o_task_info(t, fl, info, cnt);
    if (r == KERN_SUCCESS && fl == TASK_DYLD_INFO && info && o_task_info) {
        task_dyld_info_data_t* d = (task_dyld_info_data_t*)info;
        if (d->all_image_info_addr) PatchDyldImageList();
    }
    return r;
}

// ---------- csops：清掉调试标志 ----------
static int DFM_csops(pid_t pid, uint32_t ops, void* buf, size_t sz) {
    int r = o_csops ? o_csops(pid, ops, buf, sz) : -1;
    if (r == 0 && buf && ops == 0 /* CS_OPS_STATUS */ && sz >= 4) {
        uint32_t* st = (uint32_t*)buf;
        *st &= ~((uint32_t)0x10000000 | (uint32_t)0x00000100);  // CS_DEBUGGED | CS_RESTRICT
    }
    return r;
}

// ---------- 反调试 ----------
static int    DFM_getppid(void) { return 1; }
static long   DFM_ptrace(int req, pid_t pid, caddr_t addr, int data) {
    // 吞掉 PT_DENY_ATTACH / PT_TRACE_ME，避免被上游用 ptrace 反制
    if (req == PT_DENY_ATTACH || req == PT_TRACE_ME) return 0;
    return o_ptrace ? o_ptrace(req, pid, addr, data) : -1;
}
static int DFM_sysctl(int* name, u_int namelen, void* oldp, size_t* oldlenp,
                      void* newp, size_t newlen) {
    int r = o_sysctl ? o_sysctl(name, namelen, oldp, oldlenp, newp, newlen) : -1;
    // CTL_KERN / KERN_PROC / KERN_PROC_PID：清掉 P_TRACED 位
    if (r == 0 && name && namelen >= 4 && name[0] == CTL_KERN && name[1] == KERN_PROC) {
        if (oldp && oldlenp && *oldlenp >= sizeof(struct kinfo_proc)) {
            struct kinfo_proc* kp = (struct kinfo_proc*)oldp;
            kp->kp_proc.p_flag &= ~P_TRACED;
        }
    }
    return r;
}

bool Stealth::IsAttached() {
    int mib[4] = { CTL_KERN, KERN_PROC, KERN_PROC_PID, getpid() };
    struct kinfo_proc info{};
    size_t sz = sizeof(info);
    int r = (o_sysctl ? o_sysctl : sysctl)(mib, 4, &info, &sz, nullptr, 0);
    if (r != 0) return false;
    return (info.kp_proc.p_flag & P_TRACED) != 0;
}

// ---------- 越狱路径伪装 ----------
static bool IsJailbreakPath(const char* p) {
    if (!p) return false;
    static const char* kBad[] = {
        "/Applications/Cydia.app", "/Applications/Sileo.app", "/Applications/Zebra.app",
        "/Library/MobileSubstrate", "/usr/lib/libsubstrate", "/usr/lib/libsubstitute",
        "/usr/lib/substitute", "/usr/sbin/sshd", "/etc/apt", "/etc/ssh",
        "/var/jb", "/var/lib/dpkg", "/private/var/lib/dpkg", "/var/binpack",
        "/usr/bin/cycript", "/usr/bin/frida", "/usr/lib/frida", "/Library/Frameworks/CydiaSubstrate.framework",
        "/usr/lib/libjailbreak", "/usr/lib/ellekit", "/var/containers/Bundle/tweaksupport",
        "/bin/bash", "/bin/sh", "/usr/bin/ssh", "/usr/libexec/cydia",
    };
    for (auto b : kBad) if (strstr(p, b)) return true;
    return false;
}

static int DFM_stat(const char* path, struct stat* buf) {
    if (IsJailbreakPath(path)) { errno = ENOENT; return -1; }
    return o_stat ? o_stat(path, buf) : stat(path, buf);
}
static int DFM_lstat(const char* path, struct stat* buf) {
    if (IsJailbreakPath(path)) { errno = ENOENT; return -1; }
    return o_lstat ? o_lstat(path, buf) : lstat(path, buf);
}
static int DFM_access(const char* path, int mode) {
    if (IsJailbreakPath(path)) { errno = ENOENT; return -1; }
    return o_access ? o_access(path, mode) : access(path, mode);
}

static void HookNSFileManager() {
    Class c = [NSFileManager class];
    SEL s1 = @selector(fileExistsAtPath:);
    Method m1 = class_getInstanceMethod(c, s1);
    if (m1) {
        IMP orig = method_getImplementation(m1);
        IMP repl = imp_implementationWithBlock(^BOOL(NSFileManager* self, NSString* path) {
            const char* p = path ? [path UTF8String] : nullptr;
            if (IsJailbreakPath(p)) return NO;
            return ((BOOL(*)(id, SEL, id))orig)(self, s1, path);
        });
        method_setImplementation(m1, repl);
    }
}

void Stealth::Install() {
    @autoreleasepool {
        // 1) dyld 符号重绑：隐藏自己的 image
        Rebind rb[] = {
            { "_dyld_image_count",     (void*)DFM_image_count,   (void**)&o_image_count },
            { "_dyld_get_image_name",  (void*)DFM_image_name,    (void**)&o_image_name },
            { "_dyld_get_image_header",(void*)DFM_image_header,  (void**)&o_image_header },
            { "dladdr",                (void*)DFM_dladdr,        (void**)&o_dladdr },
            { "getppid",               (void*)DFM_getppid,       (void**)&o_getppid },
            { "ptrace",                (void*)DFM_ptrace,        (void**)&o_ptrace },
            { "sysctl",                (void*)DFM_sysctl,        (void**)&o_sysctl },
            { "stat",                  (void*)DFM_stat,          (void**)&o_stat },
            { "lstat",                 (void*)DFM_lstat,         (void**)&o_lstat },
            { "access",                (void*)DFM_access,        (void**)&o_access },
            { "vm_region_64",          (void*)DFM_vm_region64,    (void**)&o_vm_region64 },
            { "vm_region",             (void*)DFM_vm_region64,    (void**)&o_vm_region64 },
            { "mach_vm_region_recurse",(void*)DFM_vm_recurse,     (void**)&o_vm_rec },
            { "mach_vm_read_overwrite",(void*)DFM_vm_read_overwrite,(void**)&o_vm_read },
            { "task_info",             (void*)DFM_task_info,      (void**)&o_task_info },
            { "csops",                 (void*)DFM_csops,          (void**)&o_csops },
        };
        RebindSymbols(rb, sizeof(rb) / sizeof(rb[0]));
        HookNSFileManager();

        // 2) 记录自身 image 索引 + 地址范围，然后从 dyld 表里摘掉自己
        g_selfIndex = -1;
        SelfImageIndex();
        ComputeSelfRange();
        PatchDyldImageList();
        DFM_LOG("self range: %p - %p", (void*)g_selfLo, (void*)g_selfHi);

        // 3) 后台/前台
        NSNotificationCenter* nc = [NSNotificationCenter defaultCenter];
        [nc addObserverForName:UIApplicationDidEnterBackgroundNotification
                        object:nil queue:[NSOperationQueue mainQueue]
                    usingBlock:^(NSNotification* n) { Stealth::OnEnterBackground(); }];
        [nc addObserverForName:UIApplicationWillEnterForegroundNotification
                        object:nil queue:[NSOperationQueue mainQueue]
                    usingBlock:^(NSNotification* n) { Stealth::OnEnterForeground(); }];

        DFM_LOG("stealth installed, selfIdx=%d", SelfImageIndex());
    }
}

void Stealth::InstallDyldHooks() { /* 已并入 Install */ }

void Stealth::OnEnterBackground() {
#if STEALTH_UNHOOK_BG
    DFM_LOG("background -> pause");
#endif
}

void Stealth::OnEnterForeground() {
    DFM_LOG("foreground -> resume");
}

} // namespace dfm
