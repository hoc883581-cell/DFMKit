// Runtime.mm —— 外部参数文件加载（Filza 热改）
#include "Runtime.h"
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <mach-o/dyld.h>

namespace dfm {
namespace rt {

Runtime g;

// ---------------- 极简 plist 读取（key → real/integer/true/false） ----------------
static char s_buf[65536];

static bool ReadFile(const char* path) {
    FILE* f = fopen(path, "rb");
    if (!f) return false;
    size_t n = fread(s_buf, 1, sizeof(s_buf) - 1, f);
    fclose(f);
    if (n < 8) return false;
    s_buf[n] = 0;
    return true;
}

static const char* FindKey(const char* key) {
    char pat[192];
    snprintf(pat, sizeof(pat), "<key>%s</key>", key);
    const char* p = strstr(s_buf, pat);
    if (!p) {
        // 兼容不带前缀的写法：<key>fovDeg</key>
        return nullptr;
    }
    p += strlen(pat);
    while (*p == ' ' || *p == '\t' || *p == '\r' || *p == '\n') ++p;
    return p;
}

static float GetReal(const char* key, float dflt) {
    const char* p = FindKey(key);
    if (!p) return dflt;
    if (strncmp(p, "<real>", 6) == 0)    return (float)strtod(p + 6, nullptr);
    if (strncmp(p, "<integer>", 9) == 0) return (float)strtol(p + 9, nullptr, 10);
    if (strncmp(p, "<true/>", 7) == 0)   return 1.f;
    if (strncmp(p, "<false/>", 8) == 0)  return 0.f;
    return dflt;
}

static int GetInt(const char* key, int dflt) {
    const char* p = FindKey(key);
    if (!p) return dflt;
    if (strncmp(p, "<integer>", 9) == 0) return (int)strtol(p + 9, nullptr, 10);
    if (strncmp(p, "<real>", 6) == 0)    return (int)strtod(p + 6, nullptr);
    if (strncmp(p, "<true/>", 7) == 0)   return 1;
    if (strncmp(p, "<false/>", 8) == 0)  return 0;
    return dflt;
}

static bool GetBool(const char* key, bool dflt) {
    const char* p = FindKey(key);
    if (!p) return dflt;
    if (strncmp(p, "<true/>", 7) == 0)   return true;
    if (strncmp(p, "<false/>", 8) == 0)  return false;
    if (strncmp(p, "<integer>", 9) == 0) return strtol(p + 9, nullptr, 10) != 0;
    if (strncmp(p, "<real>", 6) == 0)    return strtod(p + 6, nullptr) != 0.0;
    return dflt;
}

static void ExeDir(char* out, size_t n) {
    char exe[4096] = {0};
    uint32_t sz = sizeof(exe);
    if (_NSGetExecutablePath(exe, &sz) != 0) { out[0] = 0; return; }
    char* slash = strrchr(exe, '/');
    if (!slash) { out[0] = 0; return; }
    *slash = 0;
    snprintf(out, n, "%s", exe);
}

bool Load() {
    char dir[4096] = {0}, path[4300] = {0};
    ExeDir(dir, sizeof(dir));
    if (!dir[0]) return false;

    const char* cands[2] = { "%s/Frameworks/DFMConfig.plist", "%s/DFMConfig.plist" };
    bool ok = false;
    for (int i = 0; i < 2 && !ok; ++i) {
        snprintf(path, sizeof(path), cands[i], dir);
        ok = ReadFile(path);
    }
    if (!ok) {
        DFM_LOG("DFMConfig.plist not found, using built-in defaults");
        return false;
    }

    Runtime& r = g;
    // ---- 自瞄 ----
    r.aimEnabled       = GetBool ("aimEnabled",       r.aimEnabled);
    r.fovDeg           = GetReal ("fovDeg",           r.fovDeg);
    r.maxDegPerSec     = GetReal ("maxDegPerSec",     r.maxDegPerSec);
    r.smoothTime       = GetReal ("smoothTime",       r.smoothTime);
    r.overshoot        = GetReal ("overshoot",        r.overshoot);
    r.reactionMs       = GetReal ("reactionMs",       r.reactionMs);
    r.reactionJitMin   = GetReal ("reactionJitMin",   r.reactionJitMin);
    r.reactionJitMax   = GetReal ("reactionJitMax",   r.reactionJitMax);
    r.idleGap          = GetReal ("idleGap",          r.idleGap);
    r.idleExtraMs      = GetReal ("idleExtraMs",      r.idleExtraMs);
    r.reactionExtraMs  = GetReal ("reactionExtraMs",  r.reactionExtraMs);
    r.jitterAmp        = GetReal ("jitterAmp",        r.jitterAmp);
    r.jitterHz         = GetReal ("jitterHz",         r.jitterHz);
    r.hitRate          = GetReal ("hitRate",          r.hitRate);
    r.headBias         = GetReal ("headBias",         r.headBias);
    r.deadzoneDeg      = GetReal ("deadzoneDeg",      r.deadzoneDeg);
    r.rampInSec        = GetReal ("rampInSec",        r.rampInSec);
    r.landingDeg       = GetReal ("landingDeg",       r.landingDeg);
    r.switchCooldownMs = GetReal ("switchCooldownMs", r.switchCooldownMs);
    r.aimOnAds         = GetBool ("aimOnAds",         r.aimOnAds);
    r.aimOnFire        = GetBool ("aimOnFire",        r.aimOnFire);
    r.autoRestMin      = GetInt  ("autoRestMin",      r.autoRestMin);

    // ---- 透视 ----
    r.espEnabled       = GetBool ("espEnabled",       r.espEnabled);
    r.bone             = GetBool ("bone",             r.bone);
    r.box              = GetBool ("box",              r.box);
    r.hpBar            = GetBool ("hpBar",            r.hpBar);
    r.threeTone        = GetBool ("threeTone",        r.threeTone);
    r.drawDistText     = GetBool ("drawDistText",     r.drawDistText);
    r.lineThick        = GetReal ("lineThick",        r.lineThick);
    r.espMaxDist       = GetReal ("espMaxDist",       r.espMaxDist);

    // ---- 护栏 ----
    r.guardHitRate     = GetReal ("guardHitRate",     r.guardHitRate);
    r.guardHeadRate    = GetReal ("guardHeadRate",    r.guardHeadRate);
    r.guardKills       = GetInt  ("guardKills",       r.guardKills);
    r.guardAngular     = GetReal ("guardAngular",     r.guardAngular);

    r.profileDay       = GetInt  ("profileDay",       r.profileDay);
    r.loaded = true;
    DFM_LOG("config loaded from %s", path);
    return true;
}

bool SaveTemplate() {
    char dir[4096] = {0}, path[4300] = {0};
    ExeDir(dir, sizeof(dir));
    if (!dir[0]) return false;
    snprintf(path, sizeof(path), "%s/Frameworks/DFMConfig.plist", dir);
    FILE* f = fopen(path, "wb");
    if (!f) {
        snprintf(path, sizeof(path), "%s/DFMConfig.plist", dir);
        f = fopen(path, "wb");
        if (!f) return false;
    }
    Runtime& r = g;
    int n = fprintf(f,
"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
"<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">\n"
"<plist version=\"1.0\"><dict>\n"
"  <!-- ===== 自瞄 ===== -->\n"
"  <key>aimEnabled</key><%s/>\n"
"  <key>fovDeg</key><real>%.2f</real>\n"
"  <key>maxDegPerSec</key><real>%.1f</real>\n"
"  <key>smoothTime</key><real>%.3f</real>\n"
"  <key>overshoot</key><real>%.3f</real>\n"
"  <key>reactionMs</key><real>%.1f</real>\n"
"  <key>reactionJitMin</key><real>%.1f</real>\n"
"  <key>reactionJitMax</key><real>%.1f</real>\n"
"  <key>idleGap</key><real>%.2f</real>\n"
"  <key>idleExtraMs</key><real>%.1f</real>\n"
"  <key>reactionExtraMs</key><real>%.1f</real>\n"
"  <key>jitterAmp</key><real>%.3f</real>\n"
"  <key>jitterHz</key><real>%.2f</real>\n"
"  <key>hitRate</key><real>%.2f</real>\n"
"  <key>headBias</key><real>%.2f</real>\n"
"  <key>deadzoneDeg</key><real>%.3f</real>\n"
"  <key>rampInSec</key><real>%.3f</real>\n"
"  <key>landingDeg</key><real>%.2f</real>\n"
"  <key>switchCooldownMs</key><real>%.0f</real>\n"
"  <key>aimOnAds</key><%s/>\n"
"  <key>aimOnFire</key><%s/>\n"
"  <key>autoRestMin</key><integer>%d</integer>\n"
"  <!-- ===== 透视 ===== -->\n"
"  <key>espEnabled</key><%s/>\n"
"  <key>bone</key><%s/>\n"
"  <key>box</key><%s/>\n"
"  <key>hpBar</key><%s/>\n"
"  <key>threeTone</key><%s/>\n"
"  <key>drawDistText</key><%s/>\n"
"  <key>lineThick</key><real>%.2f</real>\n"
"  <key>espMaxDist</key><real>%.1f</real>\n"
"  <!-- ===== 行为护栏 ===== -->\n"
"  <key>guardHitRate</key><real>%.2f</real>\n"
"  <key>guardHeadRate</key><real>%.2f</real>\n"
"  <key>guardKills</key><integer>%d</integer>\n"
"  <key>guardAngular</key><real>%.0f</real>\n"
"  <key>profileDay</key><integer>%d</integer>\n"
"</dict></plist>\n",
        r.aimEnabled ? "true" : "false", r.fovDeg, r.maxDegPerSec, r.smoothTime, r.overshoot,
        r.reactionMs, r.reactionJitMin, r.reactionJitMax, r.idleGap, r.idleExtraMs, r.reactionExtraMs,
        r.jitterAmp, r.jitterHz, r.hitRate, r.headBias, r.deadzoneDeg, r.rampInSec, r.landingDeg,
        r.switchCooldownMs, r.aimOnAds ? "true" : "false", r.aimOnFire ? "true" : "false", r.autoRestMin,
        r.espEnabled ? "true" : "false", r.bone ? "true" : "false", r.box ? "true" : "false",
        r.hpBar ? "true" : "false", r.threeTone ? "true" : "false", r.drawDistText ? "true" : "false",
        r.lineThick, r.espMaxDist,
        r.guardHitRate, r.guardHeadRate, r.guardKills, r.guardAngular, r.profileDay);
    fclose(f);
    DFM_LOG("config template written: %s (%d bytes)", path, n);
    return n > 0;
}

} // namespace rt
} // namespace dfm
