// DFMCommon.h —— 基础类型、内存读写、字符串加密
#pragma once
#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <string>
#include <array>
#include <utility>
#include <vector>
#include <mach/mach.h>
#include <mach-o/dyld.h>
#include <objc/runtime.h>

namespace dfm {

typedef int32_t  i32;
typedef uint32_t u32;
typedef int64_t  i64;
typedef uint64_t u64;
typedef uintptr_t uptr;

// ---------------- UE 基础数学 ----------------
struct FVector   { float X, Y, Z; };
struct FVector2D { float X, Y; };
struct FRotator  { float Pitch, Yaw, Roll; };
struct FLinearColor { float R, G, B, A; };
struct FName     { i32 Index; i32 Number; };

// ---------------- 安全内存访问 ----------------
// 所有读取都过 IsReadable，避免 ACE 保护页导致 EXC_BAD_ACCESS
bool IsReadable(const void* p, size_t n);

template <typename T>
inline bool Rd(const void* base, size_t off, T& out) {
    if (!base) return false;
    const void* p = (const uint8_t*)base + off;
    if (!IsReadable(p, sizeof(T))) return false;
    ::memcpy(&out, p, sizeof(T));
    return true;
}
inline void* Ptr(const void* base, size_t off) {
    void* v = nullptr;
    return Rd<void*>(base, off, v) ? v : nullptr;
}
template <typename T>
inline void Wr(void* base, size_t off, const T& v) {
    if (!base) return;
    void* p = (uint8_t*)base + off;
    if (!IsReadable(p, sizeof(T))) return;
    ::memcpy(p, &v, sizeof(T));
}

// ---------------- 编译期字符串加密（XOR） ----------------
// 二进制里不出现 aimbot / esp / cheat 等可扫描特征
constexpr char KeyOf(size_t i) { return (char)(0x5A + (i * 31) % 97); }

template <size_t N>
struct Secret {
    char buf[N];
    constexpr Secret(const char (&s)[N]) : buf{} {
        for (size_t i = 0; i < N; ++i) buf[i] = (char)(s[i] ^ KeyOf(i));
    }
    void Get(char* out) const {
        for (size_t i = 0; i < N; ++i) out[i] = (char)(buf[i] ^ KeyOf(i));
    }
    std::string Str() const { char o[N]; Get(o); return std::string(o); }
};

#define DFM_STR(lit) ([&]{ static constexpr Secret<sizeof(lit)> _s(lit); return _s.Str(); }())

// ---------------- 日志（发布版默认关闭） ----------------
#ifndef DFM_DEBUG
#define DFM_DEBUG 0
#endif

#if DFM_DEBUG
#include <os/log.h>
#define DFM_LOG(fmt, ...) os_log(OS_LOG_DEFAULT, "[DFM] " fmt, ##__VA_ARGS__)
#else
#define DFM_LOG(fmt, ...) do {} while (0)
#endif

} // namespace dfm
