// Aimbot.mm —— 人类化自瞄实现
#include "Aimbot.h"
#include "Overlay.h"
#include "UE4.h"
#include "BehaviorGuard.h"
#include "Runtime.h"
#include <cmath>
#include <random>
#include <unordered_set>
#include <algorithm>
#include <initializer_list>

namespace dfm {

// ---------------- 数学 ----------------
static std::mt19937 g_rng(0x9E3779B9u);
static inline float Rnd(float a, float b) {
    std::uniform_real_distribution<float> d(a, b);
    return d(g_rng);
}
static inline float Clampf(float v, float a, float b) { return v < a ? a : (v > b ? b : v); }
static inline float Norm180(float d) {
    while (d > 180.f) d -= 360.f;
    while (d < -180.f) d += 360.f;
    return d;
}
static inline FVector LerpV(const FVector& a, const FVector& b, float t) {
    return { a.X + (b.X - a.X) * t, a.Y + (b.Y - a.Y) * t, a.Z + (b.Z - a.Z) * t };
}
static inline FVector2D LerpS(const FVector2D& a, const FVector2D& b, float t) {
    return { a.X + (b.X - a.X) * t, a.Y + (b.Y - a.Y) * t };
}
static inline float LenV(const FVector& v) { return sqrtf(v.X*v.X + v.Y*v.Y + v.Z*v.Z); }
static inline float DistV(const FVector& a, const FVector& b) {
    float dx = a.X-b.X, dy = a.Y-b.Y, dz = a.Z-b.Z;
    return sqrtf(dx*dx + dy*dy + dz*dz);
}
static inline bool ZeroV(const FVector& v) {
    return fabsf(v.X) < 0.001f && fabsf(v.Y) < 0.001f && fabsf(v.Z) < 0.001f;
}

// ---------------- HumanAim ----------------
void HumanAim::Reset() {
    velP = velY = 0.f;
    t = 0.f;
    reactLeft = 0.f;
    rampT = 0.f;
    switchCd = 0.f;
    lockedTarget = nullptr;
    noiseWalk = 0.f;
    inited = false;
}

float HumanAim::ScreenToDegX(float px, float screenW) const {
    if (screenW <= 1.f) return 0.f;
    // 水平 FOV 近似：UE4 手游默认 90°，与屏幕宽度线性映射
    const float hFov = 90.f;
    return px / screenW * hFov;
}
float HumanAim::ScreenToDegY(float px, float screenH) const {
    if (screenH <= 1.f) return 0.f;
    const float vFov = 58.f;   // 16:9 竖屏竖向量场近似
    return px / screenH * vFov;
}

bool HumanAim::Step(float dt, void* pc, const AimTarget& tgt, FRotator& outDelta, bool justLocked) {
    if (dt <= 0.f) return false;
    dt = Clampf(dt, 0.001f, 0.05f);
    t += dt;

    // ---- 目标切换：重置曲线 + 反应延迟 ----
    if (lockedTarget != tgt.pawn) {
        lockedTarget = tgt.pawn;
        velP = velY = 0.f;
        rampT = 0.f;
        // 待机后首次锁定 → 额外 0–25ms（回神），连续交火则直接用基础区间
        float idleBonus = 0.f;
        if (idleTime > idleGap) idleBonus = Rnd(0.f, idleExtraMs);
        float react = reactionMs + reactionExtraMs + idleBonus
                    + Rnd(reactionMsJMin, reactionMsJ);
        reactLeft = react / 1000.f;
        idleTime = 0.f;
        DFM_LOG("lock: react=%dms idle=%dms", (int)react, (int)idleBonus);
        noiseA = Rnd(0.f, 6.2831853f);
        noiseB = Rnd(0.f, 6.2831853f);
        headBias = Clampf((0.35f + Rnd(-0.12f, 0.12f)) * headScale, 0.05f, 0.60f);
    }
    if (reactLeft > 0.f) {                 // 人类反应时间，先不动
        reactLeft -= dt;
        return false;
    }

    // ---- 抖动噪声（两层：正弦 + 随机游走） ----
    noiseWalk = Clampf(noiseWalk + Rnd(-1.f, 1.f) * dt * 2.6f, -1.f, 1.f);
    float nFast = 0.62f * sinf(6.2831853f * jitterHz * t + noiseA) + 0.38f * noiseWalk;
    float nSlow = sinf(6.2831853f * 0.68f * t + noiseB);

    // ---- 瞄准点：头部↔颈部之间，偏头，带轻微漂移 ----
    FVector2D neckS = tgt.neckScr;
    if (neckS.X == 0.f && neckS.Y == 0.f) neckS = { tgt.headScr.X, tgt.headScr.Y + 26.f };
    FVector2D base = LerpS(tgt.headScr, neckS, Clampf(headBias + 0.13f * nSlow, 0.05f, 0.95f));
    float sH = ov::ScreenH(), sW = ov::ScreenW();
    float pxPerDegY = sH / 58.f;
    float pxPerDegX = sW / 90.f;
    float jA = jitterAmp * Clampf(intensity + 0.25f, 0.5f, 1.4f);
    base.X += jA * pxPerDegX * 0.55f * nFast;
    base.Y += jA * pxPerDegY * 1.00f * nFast;

    // ---- 屏幕误差 → 角度误差 ----
    float cx = sW * 0.5f, cy = sH * 0.5f;
    float dYaw   =  ScreenToDegX(base.X - cx, sW);
    float dPitch = -ScreenToDegY(base.Y - cy, sH);

    if (!inited) { inited = true; lastWishScr = base; }
    lastWishScr = base;

    // ---- 死区 ----
    if (fabsf(dYaw) < rt::g.deadzoneDeg && fabsf(dPitch) < rt::g.deadzoneDeg) {
        velP = velY = 0.f;
        return false;
    }

    // ---- 临界阻尼弹簧 ----
    float w = 6.2831853f / Clampf(smoothTime, 0.05f, 0.6f);
    float zeta = 1.f / (1.f + Clampf(overshoot, 0.f, 0.5f));
    velY += (dYaw   * w * w - 2.f * zeta * w * velY) * dt;
    velP += (dPitch * w * w - 2.f * zeta * w * velP) * dt;

    // ---- 起步缓动（模拟手腕发力 0.18s） ----
    rampT += dt;
    float ramp = Clampf(rampT / rt::g.rampInSec, 0.f, 1.f);
    float ease = ramp * ramp * (3.f - 2.f * ramp);

    // ---- 软着陆：剩余角距越小，最大步长越小 ----
    float landY = Clampf(fabsf(dYaw)   / rt::g.landingDeg, 0.22f, 1.f);
    float landP = Clampf(fabsf(dPitch) / rt::g.landingDeg, 0.22f, 1.f);
    float cap = maxDegPerSec * Clampf(intensity, 0.30f, 1.20f);
    float maxY = cap * dt * (0.30f + 0.70f * ease) * landY;
    float maxP = cap * dt * (0.30f + 0.70f * ease) * landP;

    outDelta.Yaw   = Clampf(velY * dt, -maxY, maxY);
    outDelta.Pitch = Clampf(velP * dt, -maxP, maxP);
    outDelta.Roll  = 0.f;

    // 到位后速度衰减，避免第 2 帧继续冲
    if (fabsf(dYaw) < 0.6f)   velY *= 0.5f;
    if (fabsf(dPitch) < 0.6f) velP *= 0.5f;
    return fabsf(outDelta.Yaw) > 1e-5f || fabsf(outDelta.Pitch) > 1e-5f;
}

// ---------------- Aimbot ----------------
Aimbot& Aimbot::Shared() { static Aimbot a; return a; }

void Aimbot::ApplyRuntime() {
    auto& r = rt::g;
    m_human.fovDeg          = r.fovDeg;
    m_human.maxDegPerSec    = r.maxDegPerSec;
    m_human.smoothTime      = r.smoothTime;
    m_human.overshoot       = r.overshoot;
    m_human.jitterAmp       = r.jitterAmp;
    m_human.jitterHz        = r.jitterHz;
    m_human.reactionMs      = r.reactionMs;
    m_human.reactionMsJMin  = r.reactionJitMin;
    m_human.reactionMsJ     = r.reactionJitMax;
    m_human.idleGap         = r.idleGap;
    m_human.idleExtraMs     = r.idleExtraMs;
    m_human.reactionExtraMs = r.reactionExtraMs;
    DFM_LOG("aim runtime: fov=%.1f dps=%.0f react=%.0f+%.0f~%.0f",
            r.fovDeg, r.maxDegPerSec, r.reactionMs, r.reactionJitMin, r.reactionJitMax);
}

static FVector BoneOf(void* mesh, std::initializer_list<const char*> cands) {
    for (auto n : cands) {
        if (!n) continue;
        FVector v = ue4::SocketLocation(mesh, n);
        if (!ZeroV(v)) return v;
    }
    return FVector{0,0,0};
}

// 角色类集合缓存（避免每帧做字符串比较）
static std::unordered_set<void*> g_charClasses;
static float g_classRefresh = 0.f;

static bool EndsWith(const std::string& s, const char* suf) {
    size_t n = strlen(suf);
    return s.size() >= n && s.compare(s.size() - n, n, suf) == 0;
}

static void RefreshCharClasses() {
    g_charClasses.clear();
    u32 n = ue4::NumObjects();
    for (u32 i = 0; i < n; ++i) {
        void* o = ue4::ObjectAt(i);
        if (!o) continue;
        void* c = ue4::ClassOf(o);
        if (!c) continue;
        if (g_charClasses.count(c)) continue;
        std::string cn = ue4::NameOfObject(c);
        if (cn.empty()) continue;
        bool isChar = (cn == "Character") || EndsWith(cn, "Character") || EndsWith(cn, "Character_C")
                      || (EndsWith(cn, "_C") && cn.find("Character") != std::string::npos);
        if (isChar) g_charClasses.insert(c);
    }
    DFM_LOG("char classes: %zu", g_charClasses.size());
}

int Aimbot::TeamOf(void* actor) {
    // 依次尝试 PlayerState / Pawn / Controller 上的队伍字段
    void* ps = ue4::GetObjProp(actor, "PlayerState");
    int v = 0;
    if (ps && ue4::GetIntProp(ps, "TeamID", v)) return v;
    if (ps && ue4::GetIntProp(ps, "Team", v)) return v;
    if (ue4::GetIntProp(actor, "TeamID", v)) return v;
    if (ue4::GetIntProp(actor, "Team", v)) return v;
    return -1;
}

void Aimbot::Scan() {
    m_targets.clear();
    void* pc = ue4::LocalPC();
    void* me = ue4::LocalPawn();
    if (!pc) return;
    if (g_classRefresh <= 0.f) { RefreshCharClasses(); g_classRefresh = 5.f; }
    int myTeam = me ? TeamOf(me) : -1;
    FVector myPos = me ? ue4::ActorLocation(me) : FVector{0,0,0};

    u32 n = ue4::NumObjects();
    int budget = 24;   // 每轮最多做 24 个敌人的可见性射线，控制开销
    for (u32 i = 0; i < n; ++i) {
        void* o = ue4::ObjectAt(i);
        if (!o) continue;
        void* cls = ue4::ClassOf(o);
        if (!cls || !g_charClasses.count(cls)) continue;
        if (o == me) continue;

        void* mesh = ue4::GetObjProp(o, "Mesh");
        if (!mesh) continue;

        AimTarget t;
        t.pawn = o;
        t.mesh = mesh;
        t.head   = BoneOf(mesh, { "head", "Head", "Bip01 Head", "head_01" });
        t.neck   = BoneOf(mesh, { "neck_01", "neck", "Neck", "Bip01 Neck" });
        t.chest  = BoneOf(mesh, { "spine_03", "spine_02", "spine", "Chest" });
        t.pelvis = BoneOf(mesh, { "pelvis", "Pelvis", "Hips" });
        if (ZeroV(t.head)) continue;

        t.worldDist = DistV(t.head, myPos) / 100.f;   // UE 单位 cm → m
        if (t.worldDist > cfg::ESP_MAX_DIST) continue;

        t.isTeammate = (myTeam >= 0) && (TeamOf(o) == myTeam);
        t.scrDist = 1e9f;
        if (ue4::WorldToScreen(pc, t.head, t.headScr)) {
            float dx = t.headScr.X - ov::ScreenW() * 0.5f;
            float dy = t.headScr.Y - ov::ScreenH() * 0.5f;
            t.scrDist = sqrtf(dx*dx + dy*dy);
        }
        ue4::WorldToScreen(pc, t.neck, t.neckScr);
        ue4::WorldToScreen(pc, t.chest, t.chestScr);
        ue4::WorldToScreen(pc, t.pelvis, t.pelvisScr);
        // 腿部骨骼（骨骼线用，取不到就留零，绘制时跳过）
        FVector lth = BoneOf(mesh, {"thigh_l","Thigh_L","Bip01 L Thigh"});
        FVector lcf = BoneOf(mesh, {"calf_l","Calf_L","Bip01 L Calf"});
        FVector lft = BoneOf(mesh, {"foot_l","Foot_L","Bip01 L Foot"});
        FVector rth = BoneOf(mesh, {"thigh_r","Thigh_R","Bip01 R Thigh"});
        FVector rcf = BoneOf(mesh, {"calf_r","Calf_R","Bip01 R Calf"});
        FVector rft = BoneOf(mesh, {"foot_r","Foot_R","Bip01 R Foot"});
        if (!ZeroV(lth)) ue4::WorldToScreen(pc, lth, t.lThigh);
        if (!ZeroV(lcf)) ue4::WorldToScreen(pc, lcf, t.lCalf);
        if (!ZeroV(lft)) ue4::WorldToScreen(pc, lft, t.lFoot);
        if (!ZeroV(rth)) ue4::WorldToScreen(pc, rth, t.rThigh);
        if (!ZeroV(rcf)) ue4::WorldToScreen(pc, rcf, t.rCalf);
        if (!ZeroV(rft)) ue4::WorldToScreen(pc, rft, t.rFoot);
        // 血量
        float hp = 0.f, hpmax = 0.f;
        if (ue4::GetFloatProp(o, "Health", hp)) {
            if (!ue4::GetFloatProp(o, "MaxHealth", hpmax) || hpmax <= 0.f) hpmax = 100.f;
            t.hpFrac = Clampf(hp / hpmax, 0.f, 1.f);
        }

        // 可见性：掩体后 → false → 自瞄直接放弃这个目标
        if (budget > 0 && t.worldDist < 220.f) {
            t.headVisible = ue4::VisibleFromCamera(pc, t.head, o);
            t.neckVisible = !t.headVisible && ue4::VisibleFromCamera(pc, t.neck, o);
            t.bodyVisible = !(t.headVisible || t.neckVisible) && ue4::VisibleFromCamera(pc, t.chest, o);
            --budget;
        }
        BehaviorGuard::Shared().Observe(t.pawn, t.hpFrac, t.headVisible);
        m_targets.push_back(t);
    }
}

AimTarget* Aimbot::Pick() {
    AimTarget* best = nullptr;
    float bestScore = 1e18f;
    for (auto& t : m_targets) {
        if (t.isTeammate) continue;
        if (!t.anyVisible()) continue;                 // 掩体后不打
        if (t.scrDist > 1e8f) continue;
        // FOV：按屏幕像素角距换算（受行为护栏缩放）
        float pxPerDeg = ov::ScreenH() / 58.f;
        float fovNow = m_human.fovDeg * BehaviorGuard::Shared().State().fovScale;
        if (t.scrDist > fovNow * pxPerDeg) continue;

        // 打分：屏幕越近越优先，距离作为次要惩罚
        float score = t.scrDist * (1.f + t.worldDist / 9000.f);
        if (t.headVisible) score *= 0.7f;              // 露头优先
        if (score < bestScore) { bestScore = score; best = &t; }
    }
    return best;
}

FRotator Aimbot::CurRot(void* pc) {
    FRotator r{};
    u32 off = ue4::PropOffset(pc, "ControlRotation");
    if (!off) off = cfg::g_off.off_ControlRotation;
    Rd<FRotator>(pc, off, r);
    return r;
}

void Aimbot::ApplyRot(void* pc, const FRotator& r) {
    if (ue4::SetRotatorProp(pc, "ControlRotation", r)) return;
    // 兜底：反射调用 AController::SetControlRotation
    static void* fn = nullptr;
    static void* cls = nullptr;
    if (!cls) cls = ue4::FindClass("Controller");
    if (cls && !fn) fn = ue4::FindFunction(cls, "SetControlRotation");
    if (!fn) { cls = ue4::FindClass("PlayerController"); if (cls) fn = ue4::FindFunction(cls, "SetControlRotation"); }
    if (!fn) return;
    ue4::Params p(fn);
    p.SetRotator("NewRotation", r);
    ue4::ProcessEvent(pc, fn, p.buf.data());
}

bool Aimbot::ReadTrigger(void* pc, void* pawn, bool& ads, bool& fire) {
    static const char* kAds[]  = { "bIsAiming", "bAiming", "bIsADS", "bIsAimingDownSight", "bIsTargeting", "bIsAimingWeapon" };
    static const char* kFire[] = { "bIsFiring", "bFiring", "bIsWeaponFiring", "bIsTriggerPulled", "bIsShooting", "bWantToFire" };
    ads = false; fire = false;
    for (auto n : kAds)  if (ue4::GetBool(pawn, n)) { ads = true; break; }
    for (auto n : kFire) if (ue4::GetBool(pawn, n)) { fire = true; break; }
    if (!ads)  ads  = dfm::touch::Ads();
    if (!fire) fire = dfm::touch::Fire();
    return ads || fire;
}

void Aimbot::Tick(float dt) {
    if (dt <= 0.f) return;
    m_lastDt = dt;
    m_runTime += dt;
    BehaviorGuard& guard = BehaviorGuard::Shared();
    guard.Tick(dt);
    const GuardState gs = guard.State();
    if (m_human.switchCd > 0.f) m_human.switchCd -= dt;   // 冷却在这里走，不能依赖 Step
    if (g_classRefresh > 0.f) g_classRefresh -= dt;

    void* pc = ue4::LocalPC();
    void* pawn = ue4::LocalPawn();
    if (!pc || !pawn) { m_engaged = false; return; }

    // ---- 自动休息：每 40 分钟歇 5 分钟，压低在线行为强度 ----
    if (rt::g.autoRestMin > 0) {
        float period = rt::g.autoRestMin * 60.f;
        float phase = fmodf(m_runTime, period * 1.125f);
        bool rest = (phase > period);
        if (rest != m_resting) { m_resting = rest; DFM_LOG("rest=%d", (int)rest); }
        if (m_resting) { m_engaged = false; return; }
    }

    // ---- 目标扫描（30Hz） ----
    m_scanTimer -= dt;
    if (m_scanTimer <= 0.f) {
        m_scanTimer = 1.f / 30.f;
        Scan();
    }

    bool ads = false, fire = false;
    ReadTrigger(pc, pawn, ads, fire);
    bool trigger = (rt::g.aimOnAds && ads) || (rt::g.aimOnFire && fire);
    m_fireHold = fire ? (m_fireHold + dt) : 0.f;

    if (!rt::g.aimEnabled || !trigger || rt::g.fovDeg <= 0.01f) {
        m_engaged = false;
        m_human.Reset();
        return;
    }

    AimTarget* tgt = Pick();
    if (!tgt) {
        m_engaged = false;
        m_human.idleTime += dt;      // 待机计时，供下次锁定做补偿
        m_human.Reset();
        return;
    }

    // ---- 换目标冷却 ----
    if (m_human.lockedTarget && m_human.lockedTarget != tgt->pawn &&
        m_human.switchCd > 0.f) {
        return;
    }
    if (m_human.lockedTarget && m_human.lockedTarget != tgt->pawn) {
        if (!guard.AllowSwitch()) return;                // 切换过频 → 拒绝
        m_human.switchCd = (int)rt::g.switchCooldownMs / 1000.f;
        // 命中率限流：以 (1-hitRate) 概率放弃这次新锁定
        if (Rnd(0.f, 1.f) > rt::g.hitRate) {
            ++m_dropped;
            m_engaged = false;
            m_human.lockedTarget = tgt->pawn;   // 记下，避免同目标反复尝试
            return;
        }
    }

    bool justLocked = (m_human.lockedTarget != tgt->pawn);
    m_human.intensity = gs.aimScale * gs.drift;
    m_human.headScale = gs.headScale;
    if (fire) guard.ReportFireLock(dt);
    FRotator delta{};
    if (!m_human.Step(dt, pc, *tgt, delta, justLocked)) { m_engaged = false; return; }

    // 上报实际角速度（护栏用它判断"不像人"的瞬锁）
    guard.ReportAngularSpeed(sqrtf(delta.Pitch * delta.Pitch + delta.Yaw * delta.Yaw) / dt);

    FRotator cur = CurRot(pc);
    FRotator wish;
    wish.Pitch = Clampf(cur.Pitch + delta.Pitch, -89.f, 89.f);
    wish.Yaw   = Norm180(cur.Yaw + delta.Yaw);
    wish.Roll  = cur.Roll;
    ApplyRot(pc, wish);

    m_engaged = true;
    m_curPawn = tgt->pawn;
    if (justLocked) ++m_lockCount;
}

} // namespace dfm
