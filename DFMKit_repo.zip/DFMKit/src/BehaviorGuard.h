// BehaviorGuard.h —— 行为护栏：压制服务端统计学特征（防 1/3/7 天封）
#pragma once
#include "DFMCommon.h"
#include "Config.h"
#include <unordered_map>

namespace dfm {

struct GuardState {
    float aimScale  = 1.f;   // 吸附强度缩放（0.4–1.0）
    float headScale = 1.f;   // 爆头倾向缩放
    float fovScale  = 1.f;   // 视场缩放
    float drift     = 1.f;   // 长期行为漂移（0.9–1.1）
    int   reason    = 0;     // 0=正常 1=命中率 2=爆头率 3=击杀数 4=切换过频 5=角速度
    float hitRate   = 0.f;   // 当前窗口命中率
    float headRate  = 0.f;
    int   attempts  = 0;
    int   kills     = 0;
    float recover   = 0.f;   // 降级剩余恢复时间
};

class BehaviorGuard {
public:
    static BehaviorGuard& Shared();

    void Tick(float dt);                        // 每帧
    void Observe(void* pawn, float hpFrac, bool aimedHead);
    void ReportFireLock(float dt);              // 开火且锁定时调用，累计 attempt
    void ReportAngularSpeed(float degPerSec);   // 上报本帧视角角速度
    bool AllowSwitch();                         // 多目标切换限流
    GuardState State() const;
    const char* ReasonText() const;

private:
    void  PushAttempt();
    void  PushHit(bool head);
    void  Recompute();
    void  Downgrade(int reason, float aim, float head, float fov, float hold);
    int   ReadKills();

    // 滑动窗口（最近 64 次）
    uint8_t m_attemptRing[64] = {0};
    uint8_t m_hitRing[64]     = {0};
    uint8_t m_headRing[64]    = {0};
    int     m_idx = 0;
    int     m_filled = 0;

    std::unordered_map<void*, float> m_lastHp;
    std::unordered_map<void*, float> m_lastSeen;

    GuardState m_st;
    float m_fireAccum = 0.f;
    float m_driftTimer = 220.f;
    float m_switchWin[8] = {0};
    int   m_switchIdx = 0;
    float m_peakDps = 0.f;
    float m_clock = 0.f;
    int   m_kills = 0;
    float m_killCheck = 0.f;
};

} // namespace dfm
