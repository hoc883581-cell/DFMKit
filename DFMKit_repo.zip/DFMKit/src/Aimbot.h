// Aimbot.h —— 人类化自瞄（掩体漏打 / 开镜开火触发 / 头颈微抖）
#pragma once
#include "DFMCommon.h"
#include "Config.h"

namespace dfm {

struct AimTarget {
    void*   pawn = nullptr;
    void*   mesh = nullptr;
    FVector head, neck, chest, pelvis;
    FVector2D headScr, neckScr, chestScr, pelvisScr;
    FVector2D lThigh, lCalf, lFoot, rThigh, rCalf, rFoot;
    float   hpFrac = 1.f;
    float   scrDist = 1e9f;    // 距屏幕中心像素
    float   worldDist = 0.f;   // 米
    bool    headVisible = false;
    bool    neckVisible = false;
    bool    bodyVisible = false;
    bool    isTeammate = false;
    bool    anyVisible() const { return headVisible || neckVisible || bodyVisible; }
};

// 人类化瞄准曲线：弹簧 + 限速 + 缓入 + 软着陆 + 头颈噪声抖动
struct HumanAim {
    // 配置（来自 Profile）
    float fovDeg = 9.f;
    float maxDegPerSec = 210.f;
    float smoothTime = 0.16f;
    float overshoot = 0.06f;
    float jitterAmp = 0.28f;
    float jitterHz = 5.5f;
    float intensity = 1.f;      // 行为护栏：吸附强度
    float headScale = 1.f;      // 行为护栏：爆头倾向
    float reactionMs = 150.f;
    float reactionMsJ = 40.f;
    float reactionMsJMin = 10.f;
    float reactionExtraMs = 0.f;  // 护栏补偿，默认 0
    float idleTime = 0.f;         // 距上次有目标的时长（用于待机补偿）
    float idleGap = 2.5f;
    float idleExtraMs = 25.f;

    // 内部状态
    float velP = 0.f, velY = 0.f;
    float t = 0.f;
    float reactLeft = 0.f;
    float rampT = 0.f;
    float switchCd = 0.f;
    void* lockedTarget = nullptr;
    float noiseA = 0.f, noiseB = 0.f, noiseWalk = 0.f;
    float headBias = 0.35f;
    FVector2D lastWishScr;
    bool  inited = false;

    void  Reset();
    // 返回 true 表示本帧应写入 ControlRotation
    bool  Step(float dt, void* pc, const AimTarget& tgt, FRotator& outDelta, bool justLocked);
    float ScreenToDegX(float px, float screenW) const;
    float ScreenToDegY(float px, float screenH) const;
};

class Aimbot {
public:
    static Aimbot& Shared();

    void  Tick(float dt);
    const std::vector<AimTarget>& Targets() const { return m_targets; }
    bool  Engaged() const { return m_engaged; }
    void* CurrentTarget() const { return m_curPawn; }
    void  InvalidateScan() { m_scanTimer = 0.f; }
    void  ApplyRuntime();   // 从 rt::g 载入参数（Filza 改 plist 后生效）

private:
    void  Scan();
    AimTarget* Pick();
    bool  ReadTrigger(void* pc, void* pawn, bool& ads, bool& fire);
    int   TeamOf(void* actor);
    FRotator CurRot(void* pc);
    void  ApplyRot(void* pc, const FRotator& r);

    std::vector<AimTarget> m_targets;
    float m_scanTimer = 0.f;
    float m_lastDt = 1.f / 120.f;
    HumanAim m_human;
    void* m_curPawn = nullptr;
    bool  m_engaged = false;
    float m_fireHold = 0.f;
    int   m_dropped = 0;      // 本局丢弃计数（命中率限流）
    int   m_lockCount = 0;
    float m_runTime = 0.f;
    bool  m_resting = false;
};

} // namespace dfm
