// Overlay.h —— Metal 叠加渲染层 + 触摸监听
#pragma once
#include "DFMCommon.h"

namespace dfm {
namespace ov {

struct Line  { float x1, y1, x2, y2, w; float c[4]; };
struct Rect  { float x, y, w, h;       float c[4]; bool fill; };

// 屏幕信息（由 main 在启动/旋转时写入）
void  SetScreen(float w, float h, float scale);
float ScreenW();
float ScreenH();
bool  Ready();

// 帧构建（游戏线程调用，双缓冲提交给渲染线程）
void  Begin();
void  AddLine(float x1, float y1, float x2, float y2, float w,
              float r, float g, float b, float a = 1.f);
void  AddRect(float x, float y, float w, float h,
              float r, float g, float b, float a = 1.f, bool fill = false);
void  AddText(float x, float y, float pxH,
              float r, float g, float b, float a, const char* s);
void  Commit();

// 安装 presentDrawable 钩子（只 hook 一个 ObjC 方法，不新建 CAMetalLayer）
void  Install();

} // namespace ov

namespace touch {
bool Fire();
bool Ads();
void Install();
}

} // namespace dfm
