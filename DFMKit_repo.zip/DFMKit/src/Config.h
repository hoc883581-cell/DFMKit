// Config.h —— 全部可调参数 / 4 套存活阶梯 profile
#pragma once
#include "DFMCommon.h"

namespace dfm {
namespace cfg {

// ============ 运行目标开关 ============
#define PROFILE_DAY 30          // 1 / 3 / 7 / 30
static constexpr bool ESP_ENABLED = true;
static constexpr bool AIM_ENABLED = true;

enum EspMode { ESP_BONE = 0, ESP_BOX = 1, ESP_CHAMS = 2 };
#define ESP_MODE ESP_BONE       // 骨骼线最稳；方框次之；内透需额外 postprocess 资产

// ============ 自瞄 ============
// 反应延迟：固定 130ms + 随机 10–40ms  → 130–170ms（职业选手区间）
static constexpr float AIM_REACTION_MS        = 130.f;
static constexpr float AIM_REACTION_JIT_MIN   = 10.f;
static constexpr float AIM_REACTION_JIT_MAX   = 40.f;
// 待机补偿：超过 2.5s 没目标后的第一次锁定，额外 +0–25ms（高手也会"回神"）
static constexpr float AIM_REACTION_IDLE_GAP  = 2.5f;
static constexpr float AIM_REACTION_IDLE_MS   = 25.f;
// 护栏补偿：默认 0，想更保守改成 30.f
static constexpr float AIM_REACTION_EXTRA_MS  = 0.f;

#define SUPPORT_MAX   0.95f     // 由 profile 覆盖
static constexpr int AUTO_REST_MIN = 40;   // 每 40 分钟自动休息

struct Profile {
    float fovDeg;       // 屏幕角距视场
    float maxDegPerSec; // 峰值跟枪角速度
    float smoothTime;   // 弹簧时间常数（越大越软）
    float overshoot;    // 过冲比（弹性感）
    float reactionMs;   // 首次锁定反应延迟下限
    float reactionMsJ;  // 反应延迟抖动
    float jitterAmp;    // 头部↔颈部抖动幅度（度）
    float jitterHz;     // 抖动频率
    float hitRate;      // 最多吸收多少比例的目标（服务端行为）
    float headBiasMax;  // 瞄准点偏头部的最大权重
    bool  bone;         // ESP 骨骼线
    bool  box;          // ESP 方框
    bool  hpBar;        // ESP 血条
    bool  aimOnAds;     // 开镜触发
    bool  aimOnFire;    // 开火触发
    bool  threeTone;    // 红/黄绿/绿 三档着色
};

static constexpr Profile MakeProfile(int day) {
    //                        fov     dps   smooth  over   react               reactJ              jitA   jitHz  hit   head   bone   box    hp    ads   fire  three
    switch (day) {
        case 1:  return {  0.0f,   0.f, 0.20f, 0.05f, 0.f,                0.f,                 0.00f, 0.0f, 0.00f, 0.00f, false, false, false, false, false, false };
        case 3:  return {  5.0f, 150.f, 0.20f, 0.05f, AIM_REACTION_MS,     AIM_REACTION_JIT_MAX,0.18f, 4.5f, 0.55f, 0.25f, true,  false, false, true,  false, false };
        case 7:  return {  8.0f, 200.f, 0.17f, 0.06f, AIM_REACTION_MS,     AIM_REACTION_JIT_MAX,0.24f, 5.0f, 0.68f, 0.32f, true,  true,  true,  true,  true,  false };
        default: return {  9.0f, 210.f, 0.16f, 0.06f, AIM_REACTION_MS,     AIM_REACTION_JIT_MAX,0.28f, 5.5f, 0.72f, 0.35f, true,  true,  true,  true,  true,  true  };
    }
}
static constexpr Profile kProfile = MakeProfile(PROFILE_DAY);

// ============ 瞄准行为微调 ============
static constexpr float DEADZONE_DEG   = 0.15f;  // 死区，防"粘死"
static constexpr float RAMP_IN_SEC    = 0.18f;  // 起步缓动
static constexpr float LANDING_DEG    = 2.0f;   // 软着陆距离
static constexpr float AIM_BONE_MIX   = 0.35f;  // 头/颈插值基准
static constexpr float PREDICT_SCALE  = 0.85f;  // 速度前导比例
static constexpr int   PREDICT_MAX_MS = 90;     // 前导上限
static constexpr int   SWITCH_COOLDOWN_MS = 420;   // 换目标冷却，避免来回跳
static constexpr bool  AIM_ON_ADS = true;
static constexpr bool  AIM_ON_FIRE = true;

// ============ 可见性 / ESP ============
static constexpr int   VIS_SAMPLES    = 6;      // 每敌人采样骨骼点数
static constexpr float ESP_MAX_DIST   = 400.f;  // 米
static constexpr float LINE_THICK     = 1.6f;
static constexpr float BOX_PAD        = 6.f;    // px
static constexpr bool THREE_TONE = true;
static constexpr bool DRAW_HP_BAR = true;
static constexpr bool DRAW_DIST_TEXT = true;
#define SNAP_LOCK_BONE "head"

// ============ 触发兜底（反射读不到 bIsAiming/bIsFiring 时） ============
// 屏幕归一化坐标（0–1），右半屏下方 = 开火，右侧中段 = 开镜
static constexpr float FIRE_TOUCH_RECT[4] = { 0.62f, 0.55f, 0.98f, 0.95f };
static constexpr float ADS_TOUCH_RECT[4]  = { 0.62f, 0.20f, 0.98f, 0.55f };

// ============ 隐蔽 ============
#define STEALTH_HIDE_IMAGE 1
#define STEALTH_HIDE_JB    1
#define STEALTH_KILL_PTRACE 1
#define STEALTH_UNHOOK_BG  1
#define DYLIB_ALIAS "libAppSupport.dylib"

// ============ 反射偏移（可被 Offsets.plist 覆盖） ============
struct Offsets {
    // UObject
    u32 off_ClassPrivate = 0x10;
    u32 off_NamePrivate  = 0x18;
    u32 off_OuterPrivate = 0x20;
    // UStruct / UClass
    u32 off_SuperStruct  = 0x30;
    u32 off_Children     = 0x38;
    u32 off_ChildProps   = 0x40;
    u32 off_PropertiesSize = 0x48;
    u32 off_PropertyLink = 0x60;
    // FProperty (FField)
    u32 off_PropNext     = 0x20;
    u32 off_PropName     = 0x28;
    u32 off_PropArrayDim = 0x38;
    u32 off_PropElemSize = 0x3C;
    u32 off_PropOffset   = 0x4C;
    // UFunction
    u32 off_FuncFlags    = 0x88;
    u32 off_ParmsSize    = 0x8E;
    u32 off_ReturnOffset = 0x90;
    // FUObjectArray
    u32 off_ObjObjects   = 0x10;
    u32 off_MaxElements  = 0x10;   // 相对 FChunkedFixedUObjectArray
    u32 off_NumElements  = 0x14;
    // FNamePool
    u32 off_NamesBlocks  = 0x10;
    u32 off_NameStride   = 2;
    // vtable
    u32 idx_ProcessEvent = 0x44;
    // 常见属性偏移（可探测）
    u32 off_RootComponent   = 0x130;  // AActor
    u32 off_RelativeLocation= 0x11C;  // USceneComponent
    u32 off_PlayerState     = 0x2A8;  // APawn
    u32 off_AcknowledgedPawn= 0x2A0;  // APlayerController
    u32 off_ControlRotation = 0x2C8;  // AController
    u32 off_Mesh            = 0x288;  // ACharacter
};
extern Offsets g_off;

} // namespace cfg
} // namespace dfm
