// Stealth.h —— 隐蔽层
#pragma once
#include "DFMCommon.h"

namespace dfm {

class Stealth {
public:
    static void Install();          // 启动即调用（构造函数里）
    static void InstallDyldHooks(); // 隐藏自身 image
    static void OnEnterBackground();
    static void OnEnterForeground();
    static int  SelfImageIndex();
    static bool IsAttached();
};

} // namespace dfm
