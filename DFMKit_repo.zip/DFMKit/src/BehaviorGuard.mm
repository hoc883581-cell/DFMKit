// BehaviorGuard.mm —— 服务端行为特征压制
//
// 服务端判定封号（1/3/7 天）主要看这几项，全部在这里闭环控制：
//   1. 命中率        → 人类 45%–70%，超过 80% 立刻降吸附
//   2. 爆头率        → 人类 15%–35%，超过 42% 压低 headBias
//   3. 单局击杀数    → 超过 16 杀开始软降级
//   4. 多目标切换率  → 1 秒内最多 2 次，超过就拒绝换目标
//   5. 视角角速度    → 人类极限约 480°/s，超过就限速
//   6. 长期一致性    → 每 3–5 分钟微调参数，避免行为指纹固定
#include "BehaviorGuard.h"
#include "Aimbot.h"
#include "UE4.h"
#include "Runtime.h"
#include <cmath>
#include <random>

namespace dfm {

static std::mt19937 g_grng(0x2545F491u);
static inline float GRnd(float a, float b) {
    std::uniform_real_distribution<float> d(a, b);
    return d(g_grng);
}

BehaviorGuard& BehaviorGuard::Shared() { static BehaviorGuard g; return g; }

int BehaviorGuard::ReadKills() {
    void* pc = ue4::LocalPC();
    if (!pc) return m_kills;
    void* ps = ue4::GetObjProp(pc, "PlayerState");
    if (!ps) return m_kills;
    i32 v = 0;
    if (ue4::GetIntProp(ps, "Kills", v)) return v;
    if (ue4::GetIntProp(ps, "NumKills", v)) return v;
    if (ue4::GetIntProp(ps, "Score", v)) return v;
    return m_kills;
}

void BehaviorGuard::PushAttempt() {
    m_attemptRing[m_idx] = 1;
    m_hitRing[m_idx] = 0;
    m_headRing[m_idx] = 0;
    m_idx = (m_idx + 1) & 63;
    if (m_filled < 64) ++m_filled;
}

void BehaviorGuard::PushHit(bool head) {
    // 回填最近一次 attempt 的结果
    int i = (m_idx - 1) & 63;
    if (m_filled == 0) return;
    m_hitRing[i] = 1;
    m_headRing[i] = head ? 1 : 0;
}

void BehaviorGuard::Recompute() {
    int a = 0, h = 0, hd = 0;
    for (int i = 0; i < 64; ++i) {
        a += m_attemptRing[i];
        h += m_hitRing[i];
        hd += m_headRing[i];
    }
    m_st.attempts = a;
    m_st.hitRate  = a > 0 ? (float)h / (float)a : 0.f;
    m_st.headRate = h > 0 ? (float)hd / (float)h : 0.f;
    m_st.kills    = m_kills;
}

void BehaviorGuard::Downgrade(int reason, float aim, float head, float fov, float hold) {
    m_st.reason  = reason;
    m_st.aimScale  = fminf(m_st.aimScale, aim);
    m_st.headScale = fminf(m_st.headScale, head);
    m_st.fovScale  = fminf(m_st.fovScale, fov);
    m_st.recover   = fmaxf(m_st.recover, hold);
}

void BehaviorGuard::Tick(float dt) {
    if (dt <= 0.f) return;
    dt = fminf(dt, 0.1f);
    m_clock += dt;

    // ---- 击杀数（0.5s 一次，避免反射开销） ----
    m_killCheck -= dt;
    if (m_killCheck <= 0.f) {
        m_killCheck = 0.5f;
        int k = ReadKills();
        if (k < m_kills) { m_kills = k; }   // 新一局，自动回落
        m_kills = k;
    }

    // ---- 长期漂移：避免长时间参数完全一致 ----
    m_driftTimer -= dt;
    if (m_driftTimer <= 0.f) {
        m_driftTimer = GRnd(180.f, 300.f);
        m_st.drift = GRnd(0.90f, 1.10f);
    }

    // ---- 恢复 ----
    if (m_st.recover > 0.f) {
        m_st.recover -= dt;
    } else {
        m_st.aimScale  = fminf(1.f, m_st.aimScale  + 0.08f * dt);
        m_st.headScale = fminf(1.f, m_st.headScale + 0.10f * dt);
        m_st.fovScale  = fminf(1.f, m_st.fovScale  + 0.10f * dt);
        if (m_st.aimScale > 0.99f && m_st.headScale > 0.99f) m_st.reason = 0;
    }

    // ---- 规则判定（带迟滞，避免抖动） ----
    if (m_st.attempts >= 18) {
        if (m_st.hitRate > rt::g.guardHitRate) Downgrade(1, 0.62f, 0.70f, 0.85f, 30.f);
        if (m_st.headRate > rt::g.guardHeadRate) Downgrade(2, 0.85f, 0.45f, 1.00f, 25.f);
    }
    if (m_kills >= rt::g.guardKills) Downgrade(3, 0.60f, 0.75f, 0.70f, 60.f);
    if (m_peakDps > rt::g.guardAngular) Downgrade(5, 0.70f, 0.90f, 1.00f, 12.f);
    m_peakDps *= 0.90f;   // 每秒衰减

    Recompute();
}

void BehaviorGuard::Observe(void* pawn, float hpFrac, bool aimedHead) {
    if (!pawn) return;
    auto it = m_lastHp.find(pawn);
    if (it != m_lastHp.end()) {
        float last = it->second;
        // 血量下降 = 我们的子弹打中了
        if (last > 0.001f && hpFrac < last - 0.0015f) {
            PushHit(aimedHead);
        }
        it->second = hpFrac;
    } else {
        m_lastHp[pawn] = hpFrac;
    }
    m_lastSeen[pawn] = 0.f;
    if (m_lastHp.size() > 96) {   // 防泄漏：超量就清空重来
        m_lastHp.clear();
        m_lastSeen.clear();
    }
}

void BehaviorGuard::ReportFireLock(float dt) {
    m_fireAccum += dt;
    if (m_fireAccum >= 0.45f) {   // 每 0.45s 记一次"开火锁定"
        m_fireAccum = 0.f;
        PushAttempt();
    }
}

void BehaviorGuard::ReportAngularSpeed(float dps) {
    if (dps > m_peakDps) m_peakDps = dps;
}

bool BehaviorGuard::AllowSwitch() {
    // 1 秒窗口内最多 2 次换目标
    float now = m_clock;
    int recent = 0;
    for (int i = 0; i < 8; ++i) {
        if (m_switchWin[i] > 0.f && (now - m_switchWin[i]) < 1.0f) ++recent;
    }
    if (recent >= 2) {
        m_st.reason = 4;
        return false;
    }
    m_switchWin[m_switchIdx] = now;
    m_switchIdx = (m_switchIdx + 1) & 7;
    return true;
}

GuardState BehaviorGuard::State() const { return m_st; }

const char* BehaviorGuard::ReasonText() const {
    switch (m_st.reason) {
        case 1: return "hitrate";
        case 2: return "headrate";
        case 3: return "kills";
        case 4: return "switch";
        case 5: return "angular";
        default: return "ok";
    }
}

} // namespace dfm
