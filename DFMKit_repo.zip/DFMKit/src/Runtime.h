// Runtime.h —— 运行期参数（可被 Frameworks/DFMConfig.plist 覆盖）
// 目的：代码只装一次，以后在 Filza 里改 plist / 换 dylib 就生效，无需重打包
#pragma once
#include "DFMCommon.h"
#include "Config.h"

namespace dfm {
namespace rt {

struct Runtime {
    // ---------------- 自瞄 ----------------
    bool  aimEnabled        = cfg::AIM_ENABLED;
    float fovDeg            = cfg::kProfile.fovDeg;
    float maxDegPerSec      = cfg::kProfile.maxDegPerSec;
    float smoothTime        = cfg::kProfile.smoothTime;
    float overshoot         = cfg::kProfile.overshoot;
    float reactionMs        = cfg::AIM_REACTION_MS;
    float reactionJitMin    = cfg::AIM_REACTION_JIT_MIN;
    float reactionJitMax    = cfg::AIM_REACTION_JIT_MAX;
    float idleGap           = cfg::AIM_REACTION_IDLE_GAP;
    float idleExtraMs       = cfg::AIM_REACTION_IDLE_MS;
    float reactionExtraMs   = cfg::AIM_REACTION_EXTRA_MS;
    float jitterAmp         = cfg::kProfile.jitterAmp;
    float jitterHz          = cfg::kProfile.jitterHz;
    float hitRate           = cfg::kProfile.hitRate;
    float headBias          = cfg::kProfile.headBiasMax;
    float deadzoneDeg       = cfg::DEADZONE_DEG;
    float rampInSec         = cfg::RAMP_IN_SEC;
    float landingDeg        = cfg::LANDING_DEG;
    float switchCooldownMs  = (float)cfg::SWITCH_COOLDOWN_MS;
    bool  aimOnAds          = cfg::kProfile.aimOnAds;
    bool  aimOnFire         = cfg::kProfile.aimOnFire;
    int   autoRestMin       = cfg::AUTO_REST_MIN;

    // ---------------- 透视 ----------------
    bool  espEnabled        = cfg::ESP_ENABLED;
    bool  bone              = cfg::kProfile.bone;
    bool  box               = cfg::kProfile.box;
    bool  hpBar             = cfg::kProfile.hpBar;
    bool  threeTone         = cfg::kProfile.threeTone;
    bool  drawDistText      = cfg::DRAW_DIST_TEXT;
    float lineThick         = cfg::LINE_THICK;
    float espMaxDist        = cfg::ESP_MAX_DIST;

    // ---------------- 行为护栏 ----------------
    float guardHitRate      = 0.80f;
    float guardHeadRate     = 0.42f;
    int   guardKills        = 16;
    float guardAngular      = 480.f;

    int   profileDay        = PROFILE_DAY;
    bool  loaded            = false;
};

extern Runtime g;

// 从 <exeDir>/Frameworks/DFMConfig.plist（或 <exeDir>/DFMConfig.plist）读取覆盖
bool Load();
// 把当前参数写回 plist（首次运行生成一份带注释的全量配置，方便你在 Filza 里改）
bool SaveTemplate();

} // namespace rt
} // namespace dfm
