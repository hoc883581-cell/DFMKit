// Overlay.mm —— Metal 叠加层 + 触摸监听
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <Metal/Metal.h>
#import <QuartzCore/CAMetalLayer.h>
#import <objc/runtime.h>
#include "Overlay.h"
#include "Config.h"
#include <vector>
#include <mutex>
#include <atomic>
#include <cmath>
#include <cstdio>
#include <cstring>

namespace dfm {
namespace ov {

struct Vtx { float x, y, r, g, b, a; };

static std::vector<Vtx> g_front;          // 渲染线程取用
static std::vector<Vtx> g_build;          // 游戏线程构建
static std::mutex       g_mtx;
static std::atomic<bool> g_has{false};
static float g_w = 1170.f, g_h = 2532.f, g_scale = 3.f;

void SetScreen(float w, float h, float scale) { g_w = w; g_h = h; g_scale = scale > 0 ? scale : 3.f; }
float ScreenW() { return g_w; }
float ScreenH() { return g_h; }
bool  Ready()   { return g_has.load(); }

void Begin() {
    g_build.clear();
    g_build.reserve(4096);
}

static inline void Tri(float x1, float y1, float x2, float y2, float x3, float y3,
                       float r, float g, float b, float a) {
    g_build.push_back({x1, y1, r, g, b, a});
    g_build.push_back({x2, y2, r, g, b, a});
    g_build.push_back({x3, y3, r, g, b, a});
}

void AddLine(float x1, float y1, float x2, float y2, float w,
             float r, float g, float b, float a) {
    float dx = x2 - x1, dy = y2 - y1;
    float len = sqrtf(dx*dx + dy*dy);
    if (len < 0.01f) return;
    float nx = -dy / len * (w * 0.5f), ny = dx / len * (w * 0.5f);
    Tri(x1+nx, y1+ny, x2+nx, y2+ny, x2-nx, y2-ny, r, g, b, a);
    Tri(x1+nx, y1+ny, x2-nx, y2-ny, x1-nx, y1-ny, r, g, b, a);
}

void AddRect(float x, float y, float w, float h,
             float r, float g, float b, float a, bool fill) {
    if (fill) {
        Tri(x, y, x+w, y, x+w, y+h, r, g, b, a);
        Tri(x, y, x+w, y+h, x, y+h, r, g, b, a);
    } else {
        AddLine(x, y, x+w, y, 1.2f, r, g, b, a);
        AddLine(x+w, y, x+w, y+h, 1.2f, r, g, b, a);
        AddLine(x+w, y+h, x, y+h, 1.2f, r, g, b, a);
        AddLine(x, y+h, x, y, 1.2f, r, g, b, a);
    }
}

// ---------------- 3x5 点阵字体 ----------------
struct Glyph { char c; uint8_t row[5]; };
static const Glyph kFont[] = {
    {'0',{7,5,5,5,7}}, {'1',{2,6,2,2,7}}, {'2',{7,1,7,4,7}}, {'3',{7,1,7,1,7}},
    {'4',{5,5,7,1,1}}, {'5',{7,4,7,1,7}}, {'6',{7,4,7,5,7}}, {'7',{7,1,1,1,1}},
    {'8',{7,5,7,5,7}}, {'9',{7,5,7,1,7}}, {'m',{0,5,7,5,5}}, {'M',{5,7,7,5,5}},
    {'k',{4,4,6,5,5}}, {'K',{5,5,6,5,5}}, {'h',{4,4,6,5,5}}, {'H',{5,5,7,5,5}},
    {'.',{0,0,0,0,2}}, {'-',{0,0,7,0,0}}, {'%',{5,1,2,4,5}}, {' ',{0,0,0,0,0}},
    {':',{0,2,0,2,0}}, {'/',{1,1,2,4,4}}, {'x',{0,5,2,2,5}}, {'X',{5,5,2,5,5}},
};
static const Glyph* FindGlyph(char c) {
    for (auto& g : kFont) if (g.c == c) return &g;
    return nullptr;
}

void AddText(float x, float y, float pxH,
             float r, float g, float b, float a, const char* s) {
    if (!s) return;
    float dot = pxH / 5.f;
    float cw = dot * 4.f;
    float cx = x;
    for (const char* p = s; *p; ++p) {
        const Glyph* gl = FindGlyph(*p);
        if (!gl) { cx += cw; continue; }
        for (int ry = 0; ry < 5; ++ry) {
            uint8_t bits = gl->row[ry];
            for (int rx = 0; rx < 3; ++rx) {
                if (bits & (4 >> rx)) {
                    float px = cx + rx * dot, py = y + ry * dot;
                    AddRect(px, py, dot * 0.92f, dot * 0.92f, r, g, b, a, true);
                }
            }
        }
        cx += cw;
    }
}

void Commit() {
    {
        std::lock_guard<std::mutex> lk(g_mtx);
        g_front.swap(g_build);
    }
    if (!g_front.empty()) g_has.store(true);
    g_build.clear();
}

} // namespace ov

// ======================= Metal 渲染 =======================
static id<MTLDevice>              g_dev = nil;
static id<MTLRenderPipelineState> g_psoBGRA = nil;
static id<MTLRenderPipelineState> g_psoRGBA = nil;
static id<MTLBuffer>              g_ring[3] = { nil, nil, nil };
static int                        g_ringIdx = 0;
static size_t                     g_ringSize = 2 * 1024 * 1024;

static const char* kShaderSrc =
"#include <metal_stdlib>\n"
"using namespace metal;\n"
"struct Vtx { float2 pos; float4 col; };\n"
"struct VOut { float4 pos [[position]]; float4 col; };\n"
"vertex VOut v_main(const device Vtx* v [[buffer(0)]], uint i [[vertex_id]]) {\n"
"  VOut o; o.pos = float4(v[i].pos, 0.0, 1.0); o.col = v[i].col; return o; }\n"
"fragment float4 f_main(VOut in [[stage_in]]) { return in.col; }\n";

static id<MTLLibrary> LoadLibrary(id<MTLDevice> dev) {
    NSError* err = nil;
    NSString* path = [[NSBundle mainBundle] pathForResource:@"DFMOverlay" ofType:@"metallib"];
    if (!path) {
        NSString* fw = [[NSBundle mainBundle] privateFrameworksPath];
        path = [fw stringByAppendingPathComponent:@"DFMOverlay.metallib"];
    }
    if (path && [[NSFileManager defaultManager] fileExistsAtPath:path]) {
        id<MTLLibrary> lib = [dev newLibraryWithFile:path error:&err];
        if (lib) return lib;
    }
    return [dev newLibraryWithSource:[NSString stringWithUTF8String:kShaderSrc]
                             options:nil error:&err];
}

static id<MTLRenderPipelineState> MakePSO(id<MTLDevice> dev, id<MTLLibrary> lib, MTLPixelFormat fmt) {
    NSError* err = nil;
    MTLRenderPipelineDescriptor* d = [MTLRenderPipelineDescriptor new];
    d.vertexFunction   = [lib newFunctionWithName:@"v_main"];
    d.fragmentFunction = [lib newFunctionWithName:@"f_main"];
    d.colorAttachments[0].pixelFormat = fmt;
    d.colorAttachments[0].blendingEnabled = YES;
    d.colorAttachments[0].sourceRGBBlendFactor = MTLBlendFactorSourceAlpha;
    d.colorAttachments[0].destinationRGBBlendFactor = MTLBlendFactorOneMinusSourceAlpha;
    d.colorAttachments[0].sourceAlphaBlendFactor = MTLBlendFactorOne;
    d.colorAttachments[0].destinationAlphaBlendFactor = MTLBlendFactorOneMinusSourceAlpha;
    return [dev newRenderPipelineStateWithDescriptor:d error:&err];
}

static bool EnsureMetal() {
    if (g_dev && (g_psoBGRA || g_psoRGBA)) return true;
    if (!g_dev) g_dev = MTLCreateSystemDefaultDevice();
    if (!g_dev) return false;
    id<MTLLibrary> lib = LoadLibrary(g_dev);
    if (!lib) return false;
    if (!g_psoBGRA) g_psoBGRA = MakePSO(g_dev, lib, MTLPixelFormatBGRA8Unorm);
    if (!g_psoRGBA) g_psoRGBA = MakePSO(g_dev, lib, MTLPixelFormatRGBA8Unorm);
    for (int i = 0; i < 3; ++i) {
        if (!g_ring[i]) g_ring[i] = [g_dev newBufferWithLength:g_ringSize
                                                      options:MTLResourceStorageModeShared];
    }
    return (g_psoBGRA || g_psoRGBA);
}

static void DrawFrame(id<MTLCommandBuffer> cb, id<CAMetalDrawable> dr) {
    if (!cb || !dr) return;
    if (!dfm::ov::Ready()) return;
    if (!EnsureMetal()) return;

    std::vector<dfm::ov::Vtx> local;
    {
        std::lock_guard<std::mutex> lk(dfm::ov::g_mtx);
        local.swap(dfm::ov::g_front);
    }
    if (local.empty()) return;

    id<MTLTexture> tex = dr.texture;
    if (!tex) return;
    MTLPixelFormat fmt = tex.pixelFormat;
    id<MTLRenderPipelineState> pso = (fmt == MTLPixelFormatRGBA8Unorm) ? g_psoRGBA : g_psoBGRA;
    if (!pso) return;

    size_t need = local.size() * sizeof(dfm::ov::Vtx);
    if (need > g_ringSize) return;
    id<MTLBuffer> vb = g_ring[g_ringIdx++ % 3];
    if (!vb) return;
    memcpy([vb contents], local.data(), need);

    float W = (float)tex.width, H = (float)tex.height;
    if (W < 2.f || H < 2.f) return;
    // 屏幕坐标 → NDC（就地转换，避免额外拷贝）
    dfm::ov::Vtx* p = (dfm::ov::Vtx*)[vb contents];
    for (size_t i = 0; i < local.size(); ++i) {
        p[i].x = (p[i].x / W) * 2.f - 1.f;
        p[i].y = 1.f - (p[i].y / H) * 2.f;
    }

    MTLRenderPassDescriptor* rp = [MTLRenderPassDescriptor renderPassDescriptor];
    rp.colorAttachments[0].texture     = tex;
    rp.colorAttachments[0].loadAction  = MTLLoadActionLoad;   // 叠在游戏画面上
    rp.colorAttachments[0].storeAction = MTLStoreActionStore;
    id<MTLRenderCommandEncoder> enc = [cb renderCommandEncoderWithDescriptor:rp];
    if (!enc) return;
    [enc setRenderPipelineState:pso];
    [enc setVertexBuffer:vb offset:0 atIndex:0];
    [enc drawPrimitives:MTLPrimitiveTypeTriangle vertexStart:0 vertexCount:local.size()];
    [enc endEncoding];
}

// ======================= presentDrawable 钩子 =======================
static IMP    g_origPresent[192];
static Class  g_hookedClass[192];
static int    g_hookedCount = 0;
static IMP    g_fallbackPresent = NULL;

static void DFMPresent(id self, SEL _cmd, id<CAMetalDrawable> dr) {
    @try {
        DrawFrame((id<MTLCommandBuffer>)self, dr);
    } @catch (NSException* e) {
        // 渲染层任何异常都不能影响游戏画面
    }
    Class cls = object_getClass(self);
    for (int i = 0; i < g_hookedCount; ++i) {
        if (cls == g_hookedClass[i]) {
            ((void (*)(id, SEL, id))g_origPresent[i])(self, _cmd, dr);
            return;
        }
    }
    if (g_fallbackPresent) {
        ((void (*)(id, SEL, id))g_fallbackPresent)(self, _cmd, dr);
        return;
    }
    // 理论上到不了这里
    SEL sel = _cmd;
    (void)sel;
}

static void HookPresentClasses() {
    int num = objc_getClassList(NULL, 0);
    if (num <= 0) return;
    Class* classes = (Class*)malloc(sizeof(Class) * num);
    if (!classes) return;
    num = objc_getClassList(classes, num);
    for (int i = 0; i < num && g_hookedCount < 192; ++i) {
        Class c = classes[i];
        const char* nm = class_getName(c);
        if (!nm || !strstr(nm, "CommandBuffer")) continue;
        Method m = class_getInstanceMethod(c, @selector(presentDrawable:));
        if (!m) continue;
        bool already = false;
        for (int k = 0; k < g_hookedCount; ++k) if (g_hookedClass[k] == c) { already = true; break; }
        if (already) continue;
        IMP orig = method_getImplementation(m);
        if (!g_fallbackPresent) g_fallbackPresent = orig;
        g_hookedClass[g_hookedCount] = c;
        g_origPresent[g_hookedCount] = orig;
        ++g_hookedCount;
        method_setImplementation(m, (IMP)DFMPresent);
    }
    free(classes);
    DFM_LOG("present hooks: %d", g_hookedCount);
}

// ======================= 触摸监听 =======================
namespace dfm { namespace touch {
static std::atomic<bool> g_fire{false};
static std::atomic<bool> g_ads{false};
bool Fire() { return g_fire.load(std::memory_order_relaxed); }
bool Ads()  { return g_ads.load(std::memory_order_relaxed); }
static IMP g_origSendEvent = NULL;

static inline bool InRect(float nx, float ny, const float r[4]) {
    return nx >= r[0] && nx <= r[2] && ny >= r[1] && ny <= r[3];
}

static void DFMSendEvent(id self, SEL _cmd, UIEvent* ev) {
    @try {
        if (ev && ev.type == UIEventTypeTouches) {
            bool fire = false, ads = false;
            NSSet* ts = [ev allTouches];
            CGRect sb = [UIScreen mainScreen].bounds;
            for (UITouch* t in ts) {
                UITouchPhase ph = [t phase];
                if (ph == UITouchPhaseEnded || ph == UITouchPhaseCancelled) continue;
                CGPoint p = [t locationInView:nil];
                if (sb.size.width < 1.f || sb.size.height < 1.f) continue;
                float nx = (float)(p.x / sb.size.width);
                float ny = (float)(p.y / sb.size.height);
                if (InRect(nx, ny, cfg::FIRE_TOUCH_RECT)) fire = true;
                if (InRect(nx, ny, cfg::ADS_TOUCH_RECT))  ads  = true;
            }
            g_fire.store(fire, std::memory_order_relaxed);
            g_ads.store(ads, std::memory_order_relaxed);
        }
    } @catch (NSException* e) {}
    if (g_origSendEvent) ((void (*)(id, SEL, id))g_origSendEvent)(self, _cmd, ev);
}

void Install() {
    if (g_origSendEvent) return;
    Class wc = objc_getClass("UIWindow");
    if (!wc) return;
    Method m = class_getInstanceMethod(wc, @selector(sendEvent:));
    if (!m) return;
    g_origSendEvent = method_getImplementation(m);
    method_setImplementation(m, (IMP)DFMSendEvent);
    DFM_LOG("touch hook installed");
}
}} // namespace dfm::touch

namespace dfm { namespace ov {
void Install() {
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        EnsureMetal();
        HookPresentClasses();
        touch::Install();
    });
    // Metal 的 command buffer 类可能延迟注册，多补几次（幂等）
    static const int delays[] = { 1, 3, 7, 15, 30 };
    for (int d : delays) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)d * NSEC_PER_SEC),
                       dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
            HookPresentClasses();
        });
    }
}
}} // namespace dfm::ov
