#include <metal_stdlib>
using namespace metal;

struct Vtx {
    float2 pos;   // NDC (-1..1)
    float4 col;
};

struct VOut {
    float4 pos [[position]];
    float4 col;
};

vertex VOut v_main(const device Vtx* verts [[buffer(0)]], uint vid [[vertex_id]]) {
    VOut o;
    o.pos = float4(verts[vid].pos, 0.0, 1.0);
    o.col = verts[vid].col;
    return o;
}

fragment float4 f_main(VOut in [[stage_in]]) {
    return in.col;
}
